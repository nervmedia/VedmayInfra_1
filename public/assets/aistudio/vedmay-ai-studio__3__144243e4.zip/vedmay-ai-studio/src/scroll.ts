// @ts-nocheck
export function initScroll(){
const $=(s,r=document)=>r.querySelector(s),$$=(s,r=document)=>[...r.querySelectorAll(s)];
const clamp=(n,a,b)=>Math.min(b,Math.max(a,n));
const rm=matchMedia("(prefers-reduced-motion: reduce)").matches;
const hd=$("#hd"),heroIn=$("#heroIn"),shade=$("#shade"),main=$("#main"),ft=$("#ft");
const prog=el=>{const r=el.getBoundingClientRect();return clamp(-r.top/Math.max(1,r.height-innerHeight),0,1)};
const flip=$("[data-flip]"),sls=$$(".sl",flip),dots=$$(".dots i"),
 hs=$("[data-h]"),rail=$(".rail",hs),bar=$(".bar i",hs),
 life=$("[data-life]"),lp=$("p",life),col=$("[data-col]"),tiles=$$(".t",col),cv=$("[data-cv]"),card=$(".card2",cv);
lp.innerHTML=lp.dataset.text.split(" ").map(w=>"<span>"+w+"</span>").join(" ");
const words=$$("span",lp);
let zoom=0,tz=0,raf=0;
function size(){const h=ft.offsetHeight;main.style.marginBottom=h+"px"}
function frame(){
 const vh=innerHeight,y=scrollY;
 // header + hero shutter
 const wipe=clamp(y/vh,0,1);
 hd.classList.toggle("solid",y>vh*.85);hd.classList.toggle("brand-on",y>vh*.3||tBrand);
 heroIn.style.transform="scale("+(1-.1*wipe)+") translateY("+(-wipe*8)+"vh)";
 heroIn.style.opacity=1-.9*wipe;shade.style.opacity=wipe*.7;
 // pinned flip: zoom + crossfade + text rise
 tz=rm?.5:prog(flip);zoom+=(tz-zoom)*(rm?1:.2);if(Math.abs(tz-zoom)<.001)zoom=tz;
 const pos=zoom*sls.length,last=sls.length-1;
 sls.forEach((s,i)=>{let d=Math.abs(pos-i-.5);if(i===0&&pos<.5)d=0;if(i===last&&pos>last+.5)d=0;
  s.style.opacity=clamp(1.6-d*3.2,0,1);const l=clamp(pos-i,0,1);
  $(".art",s).style.transform="scale("+(1.02+.22*(i===0?clamp(pos,0,1):l))+") translateY("+(-l*2)+"%)";
  $(".cap",s).style.setProperty("--t",clamp((1-d)*2.4-.5,0,1))});
 dots.forEach((d,i)=>d.classList.toggle("on",Math.min(last,Math.floor(pos))===i));
 // horizontal rail
 const hp=prog(hs),max=Math.max(0,rail.scrollWidth-innerWidth+innerWidth*.1);
 rail.style.transform="translate3d("+(-hp*max)+"px,0,0)";bar.style.transform="scaleX("+hp+")";
 // word reveal
 const p=prog(life),N=words.length;words.forEach((w,i)=>w.style.opacity=.14+.86*clamp((p*1.25*N-i)/3,0,1));
 // parallax collage
 tiles.forEach(t=>{const r=col.getBoundingClientRect(),c=r.top+r.height/2-vh/2;t.style.transform="translate3d(0,"+(-c*t.dataset.s)+"px,0)"});
 // converse reveal
 const q=clamp(prog(cv)*2.2,0,1);
 card.style.clipPath="inset("+(1-q)*18+"% "+(1-q)*12+"% round "+(1-q)*40+"px)";
 raf=(zoom!==tz)?requestAnimationFrame(frame):0;
}
let tBrand=false;setTimeout(()=>{tBrand=true;frame()},2600);
const kick=()=>{if(!raf)raf=requestAnimationFrame(frame)};
addEventListener("scroll",kick,{passive:true});addEventListener("resize",()=>{size();kick()});
size();frame();
// in-view reveals + counters
const io=new IntersectionObserver(es=>es.forEach(e=>{if(!e.isIntersecting)return;io.unobserve(e.target);
 e.target.style.transitionDelay=([...e.target.parentNode.children].indexOf(e.target)*.12)+"s";e.target.classList.add("in");
 const b=$("b[data-n]",e.target);if(b){const n=+b.dataset.n,t0=performance.now();
  (function s(t){const k=clamp((t-t0)/1600,0,1);b.textContent=Math.round(n*(1-Math.pow(1-k,3)));if(k<1)requestAnimationFrame(s)})(t0)}}),{threshold:.25});
$$(".rv").forEach(e=>io.observe(e));
}
