import { useEffect, useRef } from "react";
import body from "./body.html?raw";
import { initScroll } from "./scroll";

export default function App() {
  const ran = useRef(false);
  useEffect(() => {
    if (ran.current) return;
    ran.current = true;
    initScroll();
  }, []);
  return <div dangerouslySetInnerHTML={{ __html: body }} />;
}
