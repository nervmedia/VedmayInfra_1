# Vedmay Infra – Home Page

React + Vite project. Run `npm install` then `npm run dev`.

- `src/body.html` – page markup (edit text, sections here)
- `src/index.css` – all styles
- `src/scroll.ts` – every scroll effect (hero shutter, pinned launches, horizontal rail, word reveal, parallax collage, count-up, closing card, pinned footer)
