import test from 'node:test';
import assert from 'node:assert/strict';
import {
  calculateMortgageEMI,
  formatCurrencyINR,
  sqFtToSqMeters,
  generateBookingReference,
  calculateVastuCompliance,
} from './calculator';

test('calculateMortgageEMI correctly computes EMI for standard luxury flat loan', () => {
  // 1.5 Cr property, 20% down payment (30 Lakh), 1.2 Cr principal, 8.5% interest, 20 years
  const res = calculateMortgageEMI(15000000, 20, 8.5, 20);
  assert.equal(res.principalAmount, 12000000);
  // Expected EMI is approx 104,139
  assert.ok(res.monthlyEMI > 100000 && res.monthlyEMI < 110000);
  assert.ok(res.totalPayable > res.principalAmount);
  assert.ok(res.totalInterest > 0);
});

test('calculateMortgageEMI handles 100% down payment with 0 EMI', () => {
  const res = calculateMortgageEMI(10000000, 100, 8.5, 20);
  assert.equal(res.principalAmount, 0);
  assert.equal(res.monthlyEMI, 0);
  assert.equal(res.totalInterest, 0);
});

test('formatCurrencyINR formats Crore and Lakh appropriately', () => {
  assert.equal(formatCurrencyINR(15000000), '₹1.50 Cr');
  assert.equal(formatCurrencyINR(20000000), '₹2 Cr');
  assert.equal(formatCurrencyINR(8500000), '₹85 Lakh');
  assert.equal(formatCurrencyINR(7550000), '₹75.50 Lakh');
});

test('sqFtToSqMeters accurately converts area', () => {
  // 2097 sq ft for Vedira Fortune
  const sqMeters = sqFtToSqMeters(2097);
  assert.equal(sqMeters, 194.8);
});

test('generateBookingReference formats project prefix and random 4-digit token', () => {
  const ref = generateBookingReference('VEDIRA FORTUNE');
  assert.match(ref, /^VEDI-\d{4}$/);
});

test('calculateVastuCompliance accurately computes alignment percentage', () => {
  const resFull = calculateVastuCompliance({
    northOrEastFacing: true,
    kitchenInSoutheast: true,
    masterInSouthwest: true,
    prayerInNortheast: true,
  });
  assert.equal(resFull.scorePercent, 100);
  assert.equal(resFull.compliantCount, 4);

  const resPartial = calculateVastuCompliance({
    northOrEastFacing: true,
    kitchenInSoutheast: true,
    masterInSouthwest: false,
    prayerInNortheast: false,
  });
  assert.equal(resPartial.scorePercent, 50);
});
