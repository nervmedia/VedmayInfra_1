/**
 * Real Estate Financial & Architectural Utility Calculations
 * Pure calculation functions decoupled from React UI
 */

export interface EMIBreakdown {
  monthlyEMI: number;
  totalInterest: number;
  totalPayable: number;
  principalAmount: number;
}

export function calculateMortgageEMI(
  propertyPrice: number,
  downPaymentPercent: number,
  annualInterestRatePercent: number,
  tenureYears: number
): EMIBreakdown {
  const downPaymentAmount = (propertyPrice * downPaymentPercent) / 100;
  const principal = Math.max(0, propertyPrice - downPaymentAmount);

  if (principal === 0 || tenureYears <= 0) {
    return {
      monthlyEMI: 0,
      totalInterest: 0,
      totalPayable: 0,
      principalAmount: 0,
    };
  }

  const monthlyRate = annualInterestRatePercent / (12 * 100);
  const totalMonths = tenureYears * 12;

  if (monthlyRate === 0) {
    const monthlyEMI = Math.round(principal / totalMonths);
    return {
      monthlyEMI,
      totalInterest: 0,
      totalPayable: principal,
      principalAmount: principal,
    };
  }

  // EMI formula: P * r * (1 + r)^n / ((1 + r)^n - 1)
  const factor = Math.pow(1 + monthlyRate, totalMonths);
  const monthlyEMI = Math.round((principal * monthlyRate * factor) / (factor - 1));
  const totalPayable = monthlyEMI * totalMonths;
  const totalInterest = Math.max(0, totalPayable - principal);

  return {
    monthlyEMI,
    totalInterest,
    totalPayable,
    principalAmount: principal,
  };
}

export function formatCurrencyINR(amount: number): string {
  if (amount >= 10000000) {
    const cr = amount / 10000000;
    return `₹${cr % 1 === 0 ? cr.toFixed(0) : cr.toFixed(2)} Cr`;
  }
  if (amount >= 100000) {
    const lac = amount / 100000;
    return `₹${lac % 1 === 0 ? lac.toFixed(0) : lac.toFixed(2)} Lakh`;
  }
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: 0,
  }).format(amount);
}

export function sqFtToSqMeters(sqft: number): number {
  return Number((sqft * 0.092903).toFixed(1));
}

export function generateBookingReference(projectName: string = 'VEDIRA'): string {
  const cleanPrefix = projectName.replace(/[^A-Z0-9]/gi, '').slice(0, 4).toUpperCase();
  const randomSuffix = Math.floor(1000 + Math.random() * 9000);
  return `${cleanPrefix}-${randomSuffix}`;
}

export function calculateVastuCompliance(elements: {
  northOrEastFacing: boolean;
  kitchenInSoutheast: boolean;
  masterInSouthwest: boolean;
  prayerInNortheast: boolean;
}): { scorePercent: number; compliantCount: number; totalCount: number } {
  const keys = Object.keys(elements) as Array<keyof typeof elements>;
  const totalCount = keys.length;
  const compliantCount = keys.filter((k) => elements[k]).length;
  const scorePercent = Math.round((compliantCount / totalCount) * 100);

  return {
    scorePercent,
    compliantCount,
    totalCount,
  };
}
