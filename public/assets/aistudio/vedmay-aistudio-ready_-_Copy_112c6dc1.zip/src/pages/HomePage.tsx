import React, { useState } from 'react';
import {
  ArrowRight,
  Sparkles,
  Building,
  Layers,
  Compass,
  MapPin,
  Calendar,
  Maximize2,
  Download,
  Phone,
  ShieldCheck,
  Award,
  TrendingUp,
  Clock,
  CheckCircle2,
  FileText,
  ExternalLink,
  Zap,
  Sun,
  Key,
  Users
} from 'lucide-react';
import { Property, PROPERTIES } from '../data/properties';
import { OurProjectsStatusFilter } from '../components/Navbar';
import { ArchitecturalImage } from '../components/ArchitecturalImage';
import { InteractiveFloorPlan } from '../components/InteractiveFloorPlan';
import { AmenitiesDeck } from '../components/AmenitiesDeck';
import { NeighborhoodMap } from '../components/NeighborhoodMap';
import { MortgageCalculator } from '../components/MortgageCalculator';

interface HomePageProps {
  onSearch: (filters: { location: string; type: string; budget: string }) => void;
  onOpenBooking: (projectName?: string) => void;
  onOpenBrochure: (projectName?: string) => void;
  onExploreFortune: () => void;
  onSelectPropertyForFloorPlan: (propertyId: string) => void;
  onOpenGallery: (property: Property) => void;
  displayProperties: Property[];
  ourProjectsFilter: OurProjectsStatusFilter;
  onOurProjectsFilterChange: (filter: OurProjectsStatusFilter) => void;
  onNavigateToAllProjects: () => void;
  onNavigateToOurProjects: () => void;
  onNavigateToAbout: () => void;
  onNavigateToContacts: () => void;
}

type EmaarCommunityFilter = 'all' | 'residential' | 'commercial' | 'townships' | 'ready-to-move';

export const HomePage: React.FC<HomePageProps> = ({
  onSearch,
  onOpenBooking,
  onOpenBrochure,
  onExploreFortune,
  onSelectPropertyForFloorPlan,
  onOpenGallery,
  displayProperties,
  ourProjectsFilter,
  onOurProjectsFilterChange,
  onNavigateToAllProjects,
  onNavigateToOurProjects,
  onNavigateToAbout,
  onNavigateToContacts,
}) => {
  const [activeCommunityTab, setActiveCommunityTab] = useState<EmaarCommunityFilter>('all');
  const [quickLocation, setQuickLocation] = useState('all');
  const [quickType, setQuickType] = useState('all');

  const allFloorPlans = PROPERTIES.flatMap((p) => p.floorPlans);

  // Filter properties for the Emaar-style Communities grid
  const filteredCommunities = PROPERTIES.filter((p) => {
    if (activeCommunityTab === 'residential') {
      return p.category === 'ultra-luxury-flats' || p.category === 'sky-mansions';
    }
    if (activeCommunityTab === 'commercial') {
      return p.category === 'commercial';
    }
    if (activeCommunityTab === 'townships') {
      return p.category === 'plotted-enclaves' || p.tabCategories.includes('communities');
    }
    if (activeCommunityTab === 'ready-to-move') {
      return p.status === 'Ready to Move' || p.tabCategories.includes('ready-to-move');
    }
    return true;
  });

  const handleQuickSearch = (e: React.FormEvent) => {
    e.preventDefault();
    onSearch({ location: quickLocation, type: quickType, budget: 'all' });
    const target = document.getElementById('communities-grid');
    if (target) {
      target.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleDownloadProposal = () => {
    const link = document.createElement('a');
    link.href = '/assets/aistudio/Vriddhi-Icon-Investor-Proposal_Mr.Vicky_efee1b58.pdf';
    link.download = 'Vriddhi-Icon-Investor-Proposal_Mr.Vicky.pdf';
    link.target = '_blank';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="bg-[#FAF9F6] text-[#14171F] min-h-screen selection:bg-[#C5A869] selection:text-[#14171F]">
      {/* =========================================================================
          1. EMAAR-INSPIRED GRAND COMMUNITIES HERO SECTION
          ========================================================================= */}
      <section className="relative min-h-[90vh] lg:min-h-[94vh] flex flex-col justify-between bg-[#11141B] text-[#FAF9F6] overflow-hidden pt-10 pb-16">
        {/* Background Visual with Subtle Ken Burns Effect */}
        <div className="absolute inset-0 z-0 overflow-hidden">
          <img
            src="/images/vedmay/vriddhi-icon/vriddhi-main-render.png"
            alt="Vedmay Infra Communities"
            className="w-full h-full object-cover object-center transform scale-105 transition-transform duration-[12000ms] ease-out hover:scale-100 opacity-40"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#11141B] via-[#11141B]/60 to-[#11141B]/40" />
          <div className="absolute inset-0 bg-radial from-transparent via-[#11141B]/50 to-[#11141B]" />
        </div>

        {/* Top Storytelling Content */}
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full pt-12 sm:pt-20">
          <div className="max-w-4xl">
            {/* Emaar Tracked Kicker */}
            <div className="inline-flex items-center gap-2.5 px-3.5 py-1.5 bg-[#FAF9F6]/10 backdrop-blur-md border border-[#C5A869]/40 rounded-full text-xs font-mono text-[#E4D2A6] uppercase tracking-[0.25em] mb-6">
              <Sparkles className="w-3.5 h-3.5 text-[#C5A869]" />
              <span>OUR COMMUNITIES · VEDMAY INFRA</span>
            </div>

            {/* Emaar High-Contrast Serif Headline */}
            <h1 className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-serif font-normal tracking-tight text-[#FAF9F6] leading-[1.08] mb-6">
              Where Vision Meets <br />
              <span className="italic font-normal text-[#E4D2A6]">Timeless Architecture.</span>
            </h1>

            <p className="text-[#D1CDC3] text-base sm:text-lg lg:text-xl font-light leading-relaxed mb-10 max-w-3xl">
              Rooted in over a decade of hands-on civil engineering mastery, Vedmay Infra crafts
              integrated plotted townships, boutique sky residences, and visionary commercial landmarks
              across Nagpur’s fastest-growing corridors.
            </p>

            {/* Action Buttons */}
            <div className="flex flex-wrap items-center gap-4">
              <button
                onClick={() => {
                  const el = document.getElementById('vriddhi-investor-showcase');
                  if (el) el.scrollIntoView({ behavior: 'smooth' });
                }}
                className="px-7 py-3.5 bg-[#C5A869] hover:bg-[#B89758] text-[#14171F] font-semibold text-xs sm:text-sm tracking-[0.16em] uppercase transition-all shadow-[0_10px_25px_rgba(197,168,105,0.3)] flex items-center gap-2.5 cursor-pointer"
              >
                <span>Vriddhi Icon Investor Proposal</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                onClick={() => {
                  const el = document.getElementById('communities-grid');
                  if (el) el.scrollIntoView({ behavior: 'smooth' });
                }}
                className="px-7 py-3.5 border border-[#FAF9F6]/40 hover:border-[#C5A869] text-[#FAF9F6] hover:text-[#E4D2A6] bg-[#11141B]/60 backdrop-blur-md text-xs sm:text-sm tracking-[0.16em] uppercase transition-all cursor-pointer"
              >
                Explore All Communities
              </button>
            </div>
          </div>
        </div>

        {/* Emaar Stats Ticker with Thin Gold Dividers */}
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full mt-16 pt-8 border-t border-[#FAF9F6]/15">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 lg:gap-8">
            <div>
              <div className="text-3xl sm:text-4xl font-serif text-[#FAF9F6] mb-1">10–12 Years</div>
              <p className="text-xs font-mono uppercase tracking-[0.18em] text-[#C5A869]">Industry Legacy</p>
              <p className="text-[11px] text-[#A6A298] mt-1 font-light">Transforming Nagpur’s real estate landscape</p>
            </div>
            <div>
              <div className="text-3xl sm:text-4xl font-serif text-[#FAF9F6] mb-1">6+ Landmark</div>
              <p className="text-xs font-mono uppercase tracking-[0.18em] text-[#C5A869]">Communities</p>
              <p className="text-[11px] text-[#A6A298] mt-1 font-light">Flats, townships & commercial parks</p>
            </div>
            <div>
              <div className="text-3xl sm:text-4xl font-serif text-[#FAF9F6] mb-1">1,200+</div>
              <p className="text-xs font-mono uppercase tracking-[0.18em] text-[#C5A869]">Delighted Families</p>
              <p className="text-[11px] text-[#A6A298] mt-1 font-light">Countless clients trusted with home & plots</p>
            </div>
            <div>
              <div className="text-3xl sm:text-4xl font-serif text-[#FAF9F6] mb-1">100%</div>
              <p className="text-xs font-mono uppercase tracking-[0.18em] text-[#C5A869]">Clear RERA Titles</p>
              <p className="text-[11px] text-[#A6A298] mt-1 font-light">NMC & NMRDA sanctioned projects</p>
            </div>
          </div>
        </div>
      </section>

      {/* =========================================================================
          2. FEATURED INVESTOR SHOWCASE: VRIDDHI ICON COMMERCIAL PARK (FROM PDF)
          ========================================================================= */}
      <section id="vriddhi-investor-showcase" className="py-20 lg:py-28 bg-[#EDE8E1] border-b border-[#D4D1C8] scroll-mt-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Header */}
          <div className="max-w-3xl mb-12">
            <div className="flex items-center gap-2 text-xs uppercase tracking-[0.25em] text-[#8D7039] font-semibold mb-3">
              <Building className="w-3.5 h-3.5 text-[#8D7039]" />
              <span>OFFICIAL INVESTOR PROPOSAL · OCTOBER 2026</span>
            </div>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-serif font-normal text-[#14171F] tracking-tight mb-4">
              Vriddhi Icon Commercial Park
            </h2>
            <p className="text-[#4A4E58] text-sm sm:text-base font-light leading-relaxed">
              A flagship commercial landmark on Manish Nagar Main Road, Nagpur. Offering high-street retail showrooms
              and premium corporate offices, backed by a secured investment structure with fixed 30% returns.
            </p>
          </div>

          {/* Proposal Hero Card with Rich Data from PDF */}
          <div className="bg-[#FAF9F6] border border-[#D4D1C8] shadow-xl rounded-sm overflow-hidden grid grid-cols-1 lg:grid-cols-12 gap-0">
            {/* Left Column: Architectural Render & Gallery */}
            <div className="lg:col-span-7 bg-[#11141B] flex flex-col justify-between p-6 sm:p-8 text-white relative">
              <div className="relative aspect-[16/10] w-full overflow-hidden rounded-xs border border-white/10 group mb-6">
                <img
                  src="/images/vedmay/vriddhi-icon/vriddhi-main-render.png"
                  alt="Vriddhi Icon Commercial Park"
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                />
                <div className="absolute top-4 left-4 bg-[#14171F]/90 backdrop-blur-md px-3 py-1 text-xs font-mono text-[#E4D2A6] uppercase tracking-wider border border-[#C5A869]/40 rounded-xs">
                  Manish Nagar Main Road, Nagpur
                </div>
                <div className="absolute bottom-4 right-4 bg-[#14171F]/90 backdrop-blur-md px-3 py-1 text-xs font-mono text-white flex items-center gap-1.5 rounded-xs">
                  <Sparkles className="w-3.5 h-3.5 text-[#C5A869]" />
                  <span>Glass Facade · 55,041 Sq Ft Built-Up</span>
                </div>
              </div>

              {/* Renders Row */}
              <div className="grid grid-cols-2 gap-4">
                <div className="relative aspect-video rounded-xs overflow-hidden border border-white/10 group cursor-pointer"
                  onClick={() => onOpenGallery(PROPERTIES.find((p) => p.id === 'vriddhi-icon')!)}
                >
                  <img
                    src="/images/vedmay/vriddhi-icon/vriddhi-facade.png"
                    alt="Vriddhi Facade"
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                  />
                  <span className="absolute bottom-2 left-2 text-[10px] font-mono text-white bg-black/70 px-2 py-0.5 rounded-xs">
                    Night Elevation
                  </span>
                </div>
                <div className="relative aspect-video rounded-xs overflow-hidden border border-white/10 group cursor-pointer"
                  onClick={() => onOpenGallery(PROPERTIES.find((p) => p.id === 'vriddhi-icon')!)}
                >
                  <img
                    src="/images/vedmay/vriddhi-icon/vriddhi-showroom.png"
                    alt="Vriddhi Showroom"
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                  />
                  <span className="absolute bottom-2 left-2 text-[10px] font-mono text-white bg-black/70 px-2 py-0.5 rounded-xs">
                    High-Street Showroom
                  </span>
                </div>
              </div>

              {/* Founder quote from PDF */}
              <div className="mt-6 pt-6 border-t border-white/10 flex items-start gap-3">
                <div className="text-2xl font-serif text-[#C5A869] leading-none">“</div>
                <div>
                  <p className="text-sm italic font-serif text-[#E4D2A6] leading-relaxed">
                    Money can start a project, but trust can build a business.
                  </p>
                  <p className="text-xs text-[#A6A298] font-mono mt-1">
                    Mr. Nikesh Vijay Kachore (Vicky Kachore) — Promoter &amp; Founder
                  </p>
                </div>
              </div>
            </div>

            {/* Right Column: Investor Terms & Offer Details from PDF */}
            <div className="lg:col-span-5 p-6 sm:p-8 flex flex-col justify-between bg-[#FAF9F6]">
              <div>
                <div className="flex items-center justify-between pb-4 border-b border-[#E2DFD6] mb-6">
                  <div>
                    <span className="text-[11px] font-mono uppercase tracking-widest text-[#8D7039] block">
                      SECURED INVESTMENT OFFER
                    </span>
                    <h3 className="text-2xl font-serif text-[#14171F] font-medium">
                      Fixed Return Proposal
                    </h3>
                  </div>
                  <span className="px-2.5 py-1 bg-emerald-50 text-emerald-800 border border-emerald-200 text-xs font-mono font-semibold rounded-xs">
                    Phase 1 Open
                  </span>
                </div>

                {/* Key Metrics Grid */}
                <div className="grid grid-cols-2 gap-4 mb-6">
                  <div className="bg-[#EAE6DF] p-3.5 rounded-xs border border-[#D4D1C8]">
                    <span className="text-[11px] font-mono uppercase tracking-wider text-[#5A5D64] block">
                      Investment Sought
                    </span>
                    <span className="text-2xl font-serif font-bold text-[#14171F] block mt-0.5">
                      ₹5 Cr
                    </span>
                    <span className="text-[11px] text-[#5A5D64]">1 Investor for Phase 1</span>
                  </div>

                  <div className="bg-[#EAE6DF] p-3.5 rounded-xs border border-[#D4D1C8]">
                    <span className="text-[11px] font-mono uppercase tracking-wider text-[#5A5D64] block">
                      Fixed Return
                    </span>
                    <span className="text-2xl font-serif font-bold text-[#8D7039] block mt-0.5">
                      30%
                    </span>
                    <span className="text-[11px] text-[#5A5D64]">18 Months Tenure</span>
                  </div>

                  <div className="bg-[#EAE6DF] p-3.5 rounded-xs border border-[#D4D1C8]">
                    <span className="text-[11px] font-mono uppercase tracking-wider text-[#5A5D64] block">
                      Total Repaid
                    </span>
                    <span className="text-2xl font-serif font-bold text-[#14171F] block mt-0.5">
                      ₹6.5 Cr
                    </span>
                    <span className="text-[11px] text-[#5A5D64]">Principal + ₹1.5 Cr Return</span>
                  </div>

                  <div className="bg-[#EAE6DF] p-3.5 rounded-xs border border-[#D4D1C8]">
                    <span className="text-[11px] font-mono uppercase tracking-wider text-[#5A5D64] block">
                      Security Cover
                    </span>
                    <span className="text-2xl font-serif font-bold text-emerald-700 block mt-0.5">
                      3.0x Cover
                    </span>
                    <span className="text-[11px] text-[#5A5D64]">Showroom 2 (₹14.73 Cr)</span>
                  </div>
                </div>

                {/* Security Specification Box */}
                <div className="bg-[#EDE8E1] p-4 rounded-xs border border-[#D4D1C8] mb-6 space-y-2 text-xs">
                  <div className="font-semibold text-[#14171F] uppercase tracking-wider flex items-center gap-1.5">
                    <ShieldCheck className="w-4 h-4 text-emerald-700" />
                    <span>Collateral Security Details:</span>
                  </div>
                  <p className="text-[#3E424B] leading-relaxed">
                    Showroom 2 on Ground (2,991 sq ft) &amp; First Floor (3,552 sq ft carpet), total
                    <strong className="text-[#14171F]"> 6,543 sq ft super built-up</strong>, held as collateral.
                    Estimated completion value is <strong className="text-[#14171F]">₹14.73 Cr</strong>.
                  </p>
                  <div className="pt-2 border-t border-[#D4D1C8] flex items-center justify-between text-[11px] font-mono text-[#5A5D64]">
                    <span>RERA ID: A50500037817</span>
                    <span>10 Min to Airport</span>
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="space-y-3 pt-4 border-t border-[#E2DFD6]">
                <button
                  onClick={handleDownloadProposal}
                  className="w-full py-3 bg-[#14171F] hover:bg-[#8D7039] text-[#FAF9F6] font-semibold text-xs uppercase tracking-[0.16em] transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-sm"
                >
                  <Download className="w-4 h-4" />
                  <span>Download Investor Proposal (PDF)</span>
                </button>

                <div className="grid grid-cols-2 gap-3">
                  <button
                    onClick={() => onOpenBooking('Vriddhi Icon Commercial Park')}
                    className="py-2.5 border border-[#14171F] hover:bg-[#14171F] hover:text-white text-[#14171F] text-xs font-semibold uppercase tracking-wider transition-colors cursor-pointer text-center"
                  >
                    Inquire as Investor
                  </button>
                  <a
                    href="tel:7709363727"
                    className="py-2.5 bg-[#E8E6E1] hover:bg-[#DCD7CD] text-[#14171F] text-xs font-semibold uppercase tracking-wider transition-colors flex items-center justify-center gap-1.5 cursor-pointer text-center"
                  >
                    <Phone className="w-3.5 h-3.5 text-[#8D7039]" />
                    <span>7709363727</span>
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* =========================================================================
          3. EMAAR-STYLE "OUR COMMUNITIES" INTERACTIVE SHOWCASE
          ========================================================================= */}
      <section id="communities-grid" className="py-24 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 scroll-mt-20">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 pb-8 border-b border-[#D4D1C8]">
          <div>
            <div className="flex items-center gap-2 text-xs uppercase tracking-[0.25em] text-[#8D7039] font-semibold mb-3">
              <Compass className="w-3.5 h-3.5 text-[#8D7039]" />
              <span>THE VEDMAY PORTFOLIO</span>
            </div>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-serif font-normal text-[#14171F] tracking-tight">
              Our Signature Communities
            </h2>
          </div>
          <p className="text-[#4A4E58] text-sm sm:text-base font-light max-w-md mt-4 md:mt-0 leading-relaxed">
            From the high-tech corridor of Manish Nagar to the verdant expanses of Wardha Road,
            explore every thoughtfully designed address.
          </p>
        </div>

        {/* Emaar Category Filter Bar with Warm Stone Palette */}
        <div className="flex flex-wrap items-center gap-2.5 mb-12 p-3 bg-[#E8E6E1] border border-[#D4D1C8] rounded-sm text-[#14171F]">
          <span className="text-xs font-semibold uppercase tracking-wider mr-2 text-[#14171F] flex items-center gap-1.5">
            <span>Filter:</span>
          </span>

          <button
            onClick={() => setActiveCommunityTab('all')}
            className={`px-4 py-2 text-xs font-semibold uppercase tracking-wider rounded-xs transition-all cursor-pointer ${
              activeCommunityTab === 'all'
                ? 'bg-[#14171F] text-[#FAF9F6] border border-[#14171F] shadow-sm'
                : 'bg-[#FAF9F6] text-[#2D313A] hover:text-[#14171F] hover:bg-[#DDD8CF] border border-[#D4D1C8]'
            }`}
          >
            All Communities ({PROPERTIES.length})
          </button>

          <button
            onClick={() => setActiveCommunityTab('residential')}
            className={`px-4 py-2 text-xs font-semibold uppercase tracking-wider rounded-xs transition-all cursor-pointer ${
              activeCommunityTab === 'residential'
                ? 'bg-[#14171F] text-[#FAF9F6] border border-[#14171F] shadow-sm'
                : 'bg-[#FAF9F6] text-[#2D313A] hover:text-[#14171F] hover:bg-[#DDD8CF] border border-[#D4D1C8]'
            }`}
          >
            Boutique Residences
          </button>

          <button
            onClick={() => setActiveCommunityTab('commercial')}
            className={`px-4 py-2 text-xs font-semibold uppercase tracking-wider rounded-xs transition-all cursor-pointer ${
              activeCommunityTab === 'commercial'
                ? 'bg-[#14171F] text-[#FAF9F6] border border-[#14171F] shadow-sm'
                : 'bg-[#FAF9F6] text-[#2D313A] hover:text-[#14171F] hover:bg-[#DDD8CF] border border-[#D4D1C8]'
            }`}
          >
            Commercial Landmarks
          </button>

          <button
            onClick={() => setActiveCommunityTab('townships')}
            className={`px-4 py-2 text-xs font-semibold uppercase tracking-wider rounded-xs transition-all cursor-pointer ${
              activeCommunityTab === 'townships'
                ? 'bg-[#14171F] text-[#FAF9F6] border border-[#14171F] shadow-sm'
                : 'bg-[#FAF9F6] text-[#2D313A] hover:text-[#14171F] hover:bg-[#DDD8CF] border border-[#D4D1C8]'
            }`}
          >
            Integrated Townships
          </button>

          <button
            onClick={() => setActiveCommunityTab('ready-to-move')}
            className={`px-4 py-2 text-xs font-semibold uppercase tracking-wider rounded-xs transition-all cursor-pointer ${
              activeCommunityTab === 'ready-to-move'
                ? 'bg-[#14171F] text-[#FAF9F6] border border-[#14171F] shadow-sm'
                : 'bg-[#FAF9F6] text-[#2D313A] hover:text-[#14171F] hover:bg-[#DDD8CF] border border-[#D4D1C8]'
            }`}
          >
            Ready for Move
          </button>
        </div>

        {/* Communities Grid - High-Definition Uncropped Imagery */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredCommunities.map((property) => (
            <div
              key={property.id}
              className="bg-[#FAF9F6] border border-[#D4D1C8] rounded-sm overflow-hidden flex flex-col justify-between hover:border-[#14171F] hover:shadow-xl transition-all duration-500 group"
            >
              <div>
                {/* Media Container with Smooth Zoom */}
                <div
                  className="relative aspect-[16/10] overflow-hidden bg-[#11141B] cursor-pointer"
                  onClick={() => onOpenGallery(property)}
                >
                  <img
                    src={property.image}
                    alt={property.title}
                    className="w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-105"
                  />

                  {/* Badges */}
                  <div className="absolute top-3 left-3 bg-[#14171F]/90 backdrop-blur-md px-2.5 py-1 text-[11px] font-mono uppercase tracking-wider text-[#E4D2A6] rounded-xs border border-white/10">
                    {property.location}
                  </div>

                  <div className="absolute top-3 right-3 bg-black/70 backdrop-blur-md px-2 py-1 text-[11px] text-white flex items-center gap-1 rounded-xs">
                    <Maximize2 className="w-3 h-3 text-[#C5A869]" />
                    <span>{property.gallery.length} Photos</span>
                  </div>

                  {property.statusKicker && (
                    <div className="absolute bottom-3 left-3 bg-[#C5A869] text-[#14171F] px-2.5 py-0.5 text-[10px] font-bold uppercase tracking-wider rounded-xs">
                      {property.statusKicker}
                    </div>
                  )}
                </div>

                {/* Content */}
                <div className="p-6">
                  <div className="flex items-baseline justify-between gap-2 mb-2">
                    <h3 className="text-2xl font-serif text-[#14171F] group-hover:text-[#8D7039] transition-colors">
                      {property.title}
                    </h3>
                  </div>

                  <p className="text-xs text-[#5A5D64] mb-3 font-medium">
                    {property.subtitle}
                  </p>

                  <p className="text-sm text-[#4A4E58] font-light leading-relaxed mb-4 line-clamp-2">
                    {property.description}
                  </p>

                  <div className="pt-3 border-t border-[#E8E6E1] flex items-center justify-between text-xs text-[#5A5D64]">
                    <span>{property.carpetAreaRange}</span>
                    <span className="font-semibold text-[#14171F]">{property.priceDisplay}</span>
                  </div>
                </div>
              </div>

              {/* Card Footer Actions */}
              <div className="p-6 pt-0 flex items-center gap-3">
                <button
                  onClick={() => onOpenGallery(property)}
                  className="flex-1 py-2.5 border border-[#14171F] text-[#14171F] hover:bg-[#14171F] hover:text-[#FAF9F6] text-xs font-semibold uppercase tracking-[0.14em] transition-colors cursor-pointer text-center"
                >
                  Explore Details
                </button>
                <button
                  onClick={() => onOpenBooking(property.title)}
                  className="px-4 py-2.5 bg-[#C5A869] hover:bg-[#B89758] text-[#14171F] text-xs font-semibold uppercase tracking-wider transition-colors cursor-pointer flex items-center justify-center gap-1.5"
                  title="Book Private Visit"
                >
                  <Calendar className="w-3.5 h-3.5" />
                  <span>Visit</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* =========================================================================
          4. THE EMAAR PHILOSOPHY: ARCHITECTURAL INTEGRITY & PILLARS
          ========================================================================= */}
      <section className="py-24 bg-[#14171F] text-[#FAF9F6] border-y border-neutral-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl mb-16">
            <div className="flex items-center gap-2 text-xs uppercase tracking-[0.25em] text-[#C5A869] font-medium mb-3">
              <Award className="w-3.5 h-3.5" />
              <span>THE VEDMAY STANDARD OF EXCELLENCE</span>
            </div>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-serif font-normal tracking-tight text-[#FAF9F6]">
              Engineered for Generations
            </h2>
            <p className="text-[#A6A298] text-sm sm:text-base font-light mt-3 leading-relaxed">
              Every master development is anchored on clear titles, precision civil engineering,
              and strategic proximity to Nagpur’s thriving civic and commercial corridors.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="border-t border-[#C5A869]/40 pt-6">
              <span className="text-3xl font-serif text-[#C5A869] block mb-2">01</span>
              <h3 className="text-lg font-serif text-white mb-2">Strategic Corridors</h3>
              <p className="text-xs text-[#A6A298] font-light leading-relaxed">
                Direct access to Wardha Road, Somalwada, and Manish Nagar with 5-minute metro connectivity.
              </p>
            </div>

            <div className="border-t border-[#C5A869]/40 pt-6">
              <span className="text-3xl font-serif text-[#C5A869] block mb-2">02</span>
              <h3 className="text-lg font-serif text-white mb-2">100% Legal Title Diligence</h3>
              <p className="text-xs text-[#A6A298] font-light leading-relaxed">
                Zero litigation, verified 7/12 records, and MahaRERA approved sanctions with transparent escrow audits.
              </p>
            </div>

            <div className="border-t border-[#C5A869]/40 pt-6">
              <span className="text-3xl font-serif text-[#C5A869] block mb-2">03</span>
              <h3 className="text-lg font-serif text-white mb-2">Vastu &amp; Structural Mastery</h3>
              <p className="text-xs text-[#A6A298] font-light leading-relaxed">
                Harmonized Vedic orientation paired with Fe-550D structural steel and earthquake-resistant RCC.
              </p>
            </div>

            <div className="border-t border-[#C5A869]/40 pt-6">
              <span className="text-3xl font-serif text-[#C5A869] block mb-2">04</span>
              <h3 className="text-lg font-serif text-white mb-2">Green Innovation</h3>
              <p className="text-xs text-[#A6A298] font-light leading-relaxed">
                Solar grid power, EV vehicle fast charging stations, and comprehensive rainwater harvesting pits.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* =========================================================================
          5. INTERACTIVE BLUEPRINT STUDIO & FLOOR PLANS
          ========================================================================= */}
      <InteractiveFloorPlan
        floorPlans={allFloorPlans}
        onOpenBooking={onOpenBooking}
        onOpenBrochure={onOpenBrochure}
      />

      {/* =========================================================================
          6. WORLD-CLASS LIFESTYLE PRIVILEGES DECK
          ========================================================================= */}
      <AmenitiesDeck onOpenBooking={() => onOpenBooking('Vedira Fortune')} />

      {/* =========================================================================
          7. STRATEGIC NAGPUR CONNECTIVITY MAP
          ========================================================================= */}
      <NeighborhoodMap />

      {/* =========================================================================
          8. INVESTMENT & MORTGAGE ROI CALCULATOR
          ========================================================================= */}
      <MortgageCalculator onOpenBooking={() => onOpenBooking('Vedira Fortune')} />
    </div>
  );
};
