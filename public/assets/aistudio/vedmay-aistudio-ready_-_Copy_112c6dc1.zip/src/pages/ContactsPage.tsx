import React, { useState } from 'react';
import {
  MapPin,
  Phone,
  Mail,
  Clock,
  Send,
  CheckCircle2,
  Calendar,
  MessageSquare,
  ShieldCheck,
  Building,
  ArrowRight,
} from 'lucide-react';
import { PROPERTIES } from '../data/properties';

interface ContactsPageProps {
  onOpenBooking: (projectName?: string) => void;
  onNavigateToOurProjects: () => void;
}

export const ContactsPage: React.FC<ContactsPageProps> = ({
  onOpenBooking,
  onNavigateToOurProjects,
}) => {
  const [formData, setFormData] = useState({
    fullName: '',
    phone: '',
    email: '',
    project: 'Vedira Fortune (Somalwada)',
    message: '',
  });
  const [submitted, setSubmitted] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setTimeout(() => {
      setIsSubmitting(false);
      setSubmitted(true);
    }, 600);
  };

  return (
    <div className="bg-[#070A0F] text-neutral-100 min-h-screen pt-8 pb-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Editorial Header Banner */}
        <div className="border-b border-neutral-800 pb-8 mb-12">
          <div className="flex items-center gap-2 text-xs uppercase tracking-[0.25em] text-amber-400 font-medium mb-3">
            <span>CONTACTS & CORPORATE SALES LOUNGE</span>
            <span aria-hidden="true">·</span>
            <span>NAGPUR HEADQUARTERS</span>
          </div>

          <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-6">
            <div>
              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-serif font-normal tracking-tight text-white mb-4">
                Connect With VEDMAY
              </h1>
              <p className="text-neutral-400 text-sm sm:text-base font-light max-w-2xl leading-relaxed">
                Experience personalized private advisory. Whether you are inquiring about a 2 BHK or 3 BHK
                residence in Somalwada, a high-rise sky mansion, or a custom villa plot near MIHAN, our Senior
                Portfolio Directors are at your service 7 days a week.
              </p>
            </div>

            <button
              onClick={onNavigateToOurProjects}
              className="self-start lg:self-end px-5 py-2.5 bg-neutral-900 hover:bg-neutral-800 text-amber-400 border border-neutral-700/80 rounded-sm text-xs font-semibold uppercase tracking-wider transition-colors flex items-center gap-2 cursor-pointer"
            >
              <span>Explore Landmark Projects</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Rapid Highlights Strip */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-14">
          <div className="bg-neutral-900/60 border border-neutral-800 p-5 rounded-sm">
            <div className="flex items-center gap-2 text-xs text-amber-400 font-mono uppercase tracking-wider mb-1">
              <Phone className="w-3.5 h-3.5" />
              <span>Direct Hotlines</span>
            </div>
            <a href="tel:+917122894500" className="text-sm font-semibold text-white hover:text-amber-300 block font-mono">
              +91 712 289 4500
            </a>
            <span className="text-[11px] text-neutral-400 mt-0.5 block font-mono">
              +91 98230 45678 (WhatsApp)
            </span>
          </div>

          <div className="bg-neutral-900/60 border border-neutral-800 p-5 rounded-sm">
            <div className="flex items-center gap-2 text-xs text-amber-400 font-mono uppercase tracking-wider mb-1">
              <MapPin className="w-3.5 h-3.5" />
              <span>Sales Office</span>
            </div>
            <span className="text-xs font-medium text-white block">Shyam Nagar, Somalwada</span>
            <span className="text-[11px] text-neutral-400 mt-0.5 block">6 mins from Airport Metro</span>
          </div>

          <div className="bg-neutral-900/60 border border-neutral-800 p-5 rounded-sm">
            <div className="flex items-center gap-2 text-xs text-amber-400 font-mono uppercase tracking-wider mb-1">
              <Clock className="w-3.5 h-3.5" />
              <span>Visiting Hours</span>
            </div>
            <span className="text-xs font-medium text-white block">9:30 AM – 7:30 PM IST</span>
            <span className="text-[11px] text-emerald-400 mt-0.5 block">Open all 7 days for visits</span>
          </div>

          <div className="bg-neutral-900/60 border border-neutral-800 p-5 rounded-sm">
            <div className="flex items-center gap-2 text-xs text-amber-400 font-mono uppercase tracking-wider mb-1">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
              <span>MahaRERA Registered</span>
            </div>
            <span className="text-xs font-medium text-white block font-mono">P50500049281</span>
            <span className="text-[11px] text-neutral-400 mt-0.5 block">100% Clear Titles</span>
          </div>
        </div>

        {/* Contact Suite: Details & Interactive Callback Form */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
          {/* Left Column: Direct Corporate Information */}
          <div className="lg:col-span-5 space-y-8">
            <div className="bg-neutral-900/70 border border-neutral-800 p-8 rounded-sm space-y-6">
              <h3 className="text-xl font-serif text-white font-medium flex items-center gap-2">
                <Building className="w-5 h-5 text-amber-400" />
                <span>Nagpur Corporate Sales Gallery</span>
              </h3>

              <div className="space-y-4 text-xs sm:text-sm text-neutral-300 font-light">
                <div className="flex items-start gap-3">
                  <MapPin className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
                  <div>
                    <strong className="text-white block font-medium mb-0.5">Corporate Address</strong>
                    <span>
                      Shyam Nagar, Jai Hind Society, Beside Amrut Lawn, Nagpur, Maharashtra, 440034
                    </span>
                    <span className="block text-[11px] text-neutral-400 mt-1 font-mono">
                      (Just 6 mins from Airport Metro Station)
                    </span>
                  </div>
                </div>

                <div className="flex items-start gap-3 pt-3 border-t border-neutral-800/80">
                  <Phone className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
                  <div>
                    <strong className="text-white block font-medium mb-0.5">Direct Hotlines</strong>
                    <div className="space-y-0.5">
                      <a
                        href="tel:+917122894500"
                        className="hover:text-amber-400 transition-colors block font-mono text-neutral-200"
                      >
                        +91 712 289 4500 (Sales Desk)
                      </a>
                      <a
                        href="tel:+919823045678"
                        className="hover:text-amber-400 transition-colors block font-mono text-neutral-200"
                      >
                        +91 98230 45678 (Direct Mobile / WhatsApp)
                      </a>
                    </div>
                  </div>
                </div>

                <div className="flex items-start gap-3 pt-3 border-t border-neutral-800/80">
                  <Mail className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
                  <div>
                    <strong className="text-white block font-medium mb-0.5">Executive Email</strong>
                    <div className="space-y-0.5">
                      <a
                        href="mailto:sales@vedmay.com"
                        className="hover:text-amber-400 transition-colors block font-mono text-neutral-200"
                      >
                        sales@vedmay.com
                      </a>
                      <a
                        href="mailto:vip@vedmay.com"
                        className="hover:text-amber-400 transition-colors block font-mono text-neutral-200"
                      >
                        vip@vedmay.com (HNIs & Investors)
                      </a>
                    </div>
                  </div>
                </div>

                <div className="flex items-start gap-3 pt-3 border-t border-neutral-800/80">
                  <Clock className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
                  <div>
                    <strong className="text-white block font-medium mb-0.5">Experience Center Hours</strong>
                    <span>Monday through Sunday: 9:30 AM – 7:30 PM (IST)</span>
                    <span className="block text-[11px] text-amber-400/90 mt-0.5">
                      Open on all weekends & public holidays for site visits.
                    </span>
                  </div>
                </div>
              </div>

              {/* Action buttons */}
              <div className="pt-2 flex flex-col sm:flex-row gap-3">
                <button
                  type="button"
                  onClick={() => onOpenBooking('Vedira Fortune')}
                  className="flex-1 py-3 bg-amber-400 hover:bg-amber-300 text-neutral-950 text-xs font-semibold uppercase tracking-wider rounded-sm transition-all flex items-center justify-center gap-2 cursor-pointer shadow-md"
                >
                  <Calendar className="w-4 h-4" />
                  <span>Book Site Walkthrough</span>
                </button>
                <a
                  href="https://wa.me/919823045678?text=Hello%20VEDMAY,%20I%20would%20like%20to%20inquire%20about%20your%20Nagpur%20projects."
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-4 py-3 bg-neutral-800 hover:bg-neutral-700 text-white text-xs font-medium uppercase tracking-wider rounded-sm transition-colors flex items-center justify-center gap-2 border border-neutral-700"
                >
                  <MessageSquare className="w-4 h-4 text-emerald-400" />
                  <span>WhatsApp</span>
                </a>
              </div>
            </div>

            {/* Credential Badge */}
            <div className="bg-neutral-900/40 border border-neutral-800/80 p-5 rounded-sm flex items-center gap-4">
              <ShieldCheck className="w-8 h-8 text-amber-400 shrink-0" />
              <div className="text-xs">
                <span className="text-white font-medium block">MahaRERA & NMRDA Registered Developer</span>
                <span className="text-neutral-400 font-mono text-[11px]">
                  RERA Reg: P50500049281 · Clean titles & approved sanctions
                </span>
              </div>
            </div>
          </div>

          {/* Right Column: Direct Callback & Inquiry Form */}
          <div className="lg:col-span-7">
            <div className="bg-neutral-900/70 border border-neutral-800 p-8 sm:p-10 rounded-sm">
              <div className="mb-6">
                <span className="text-xs uppercase tracking-wider text-amber-400 font-mono block mb-1">
                  DIRECT CLIENT INQUIRY
                </span>
                <h3 className="text-2xl font-serif text-white font-normal">
                  Request an Architectural Dossier or Callback
                </h3>
                <p className="text-xs text-neutral-400 mt-1">
                  Fill in your details below and a Dedicated Relationship Manager will connect within 15 minutes.
                </p>
              </div>

              {submitted ? (
                <div className="py-12 text-center space-y-4">
                  <div className="w-16 h-16 mx-auto rounded-full bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
                    <CheckCircle2 className="w-8 h-8" />
                  </div>
                  <h4 className="text-xl font-serif text-white">Inquiry Received Successfully</h4>
                  <p className="text-xs sm:text-sm text-neutral-300 max-w-md mx-auto font-light">
                    Thank you, <strong className="text-white">{formData.fullName || 'Valued Guest'}</strong>. Our
                    Senior Sales Director for {formData.project} will call you at{' '}
                    <span className="font-mono text-amber-300">{formData.phone}</span> shortly.
                  </p>
                  <button
                    type="button"
                    onClick={() => {
                      setSubmitted(false);
                      setFormData({
                        fullName: '',
                        phone: '',
                        email: '',
                        project: 'Vedira Fortune (Somalwada)',
                        message: '',
                      });
                    }}
                    className="mt-4 px-6 py-2.5 bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-xs uppercase tracking-wider rounded-sm transition-colors"
                  >
                    Send Another Inquiry
                  </button>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-5">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                    <div>
                      <label className="block text-xs font-medium uppercase tracking-wider text-neutral-300 mb-2">
                        Full Name <span className="text-amber-400">*</span>
                      </label>
                      <input
                        type="text"
                        required
                        placeholder="e.g. Dr. Rajesh Sharma"
                        value={formData.fullName}
                        onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                        className="w-full px-4 py-3 bg-neutral-950 border border-neutral-700 rounded-sm text-sm text-white placeholder-neutral-500 focus:outline-none focus:border-amber-400 transition-colors"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-medium uppercase tracking-wider text-neutral-300 mb-2">
                        Phone Number <span className="text-amber-400">*</span>
                      </label>
                      <input
                        type="tel"
                        required
                        placeholder="+91 98XXX XXXXX"
                        value={formData.phone}
                        onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                        className="w-full px-4 py-3 bg-neutral-950 border border-neutral-700 rounded-sm text-sm text-white placeholder-neutral-500 focus:outline-none focus:border-amber-400 transition-colors font-mono"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                    <div>
                      <label className="block text-xs font-medium uppercase tracking-wider text-neutral-300 mb-2">
                        Email Address
                      </label>
                      <input
                        type="email"
                        placeholder="name@company.com"
                        value={formData.email}
                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                        className="w-full px-4 py-3 bg-neutral-950 border border-neutral-700 rounded-sm text-sm text-white placeholder-neutral-500 focus:outline-none focus:border-amber-400 transition-colors"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-medium uppercase tracking-wider text-neutral-300 mb-2">
                        Interested Project
                      </label>
                      <select
                        value={formData.project}
                        onChange={(e) => setFormData({ ...formData, project: e.target.value })}
                        className="w-full px-4 py-3 bg-neutral-950 border border-neutral-700 rounded-sm text-sm text-white focus:outline-none focus:border-amber-400 transition-colors cursor-pointer"
                      >
                        <option value="Vedira Fortune (Somalwada)">Vedira Fortune (Somalwada) - 2 & 3 BHK</option>
                        <option value="Vedira Heights (Wardha Road)">Vedira Heights (Wardha Rd) - Sky Mansions</option>
                        <option value="Ramalaya Bliss (Ready Flats)">Ramalaya Bliss (Somalwada) - Ready to Move</option>
                        <option value="Gurukul Township (MIHAN)">Gurukul Township - Master Plotted Estate</option>
                        <option value="Vedmay Avenue One (Commercial)">Vedmay Avenue One - Commercial Suites</option>
                        <option value="All Projects / General Advisory">All Projects / Investment Advisory</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-medium uppercase tracking-wider text-neutral-300 mb-2">
                      Specific Requirements / Preferred Visit Time
                    </label>
                    <textarea
                      rows={3}
                      placeholder="Share your preferred configuration (2 BHK, 3 BHK, 4 BHK), budget range, or preferred visit date/time..."
                      value={formData.message}
                      onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                      className="w-full px-4 py-3 bg-neutral-950 border border-neutral-700 rounded-sm text-sm text-white placeholder-neutral-500 focus:outline-none focus:border-amber-400 transition-colors resize-none"
                    />
                  </div>

                  <div className="pt-2 flex flex-col sm:flex-row items-center justify-between gap-4">
                    <p className="text-[11px] text-neutral-500">
                      🔒 Your privacy is respected. No spam. Direct communication only.
                    </p>
                    <button
                      type="submit"
                      disabled={isSubmitting}
                      className="w-full sm:w-auto px-8 py-3.5 bg-amber-400 hover:bg-amber-300 text-neutral-950 text-xs font-semibold uppercase tracking-wider rounded-sm transition-all shadow-[0_0_20px_rgba(212,175,55,0.3)] flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                    >
                      {isSubmitting ? (
                        <span>Submitting...</span>
                      ) : (
                        <>
                          <span>Submit Inquiry</span>
                          <Send className="w-4 h-4" />
                        </>
                      )}
                    </button>
                  </div>
                </form>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
