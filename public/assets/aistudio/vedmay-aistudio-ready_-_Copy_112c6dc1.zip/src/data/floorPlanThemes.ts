export type FloorPlanTheme =
  | 'onyx-gold'
  | 'blueprint'
  | 'nordic-ivory'
  | 'vastu-mandala'
  | 'emerald-sanctuary'
  | 'champagne-rose'
  | 'monochrome-platinum';

export interface ThemeDefinition {
  id: FloorPlanTheme;
  name: string;
  shortName: string;
  tagline: string;
  swatchColors: [string, string, string]; // 3 primary tones
  viewportBg: string;
  gridStroke: string;
  gridOpacity: number;
  outerWallStroke: string;
  defaultRoomFill: string;
  defaultRoomStroke: string;
  selectedRoomFill: string;
  selectedRoomStroke: string;
  roomTextColor: string;
  roomSubTextColor: string;
  accentColor: string;
  pinColor: string;
  badgeBg: string;
  badgeBorder: string;
  badgeText: string;
  glowColor: string;
}

export const FLOOR_PLAN_THEMES: Record<FloorPlanTheme, ThemeDefinition> = {
  'onyx-gold': {
    id: 'onyx-gold',
    name: 'Royal Obsidian & 24K Gold',
    shortName: 'Onyx & Gold',
    tagline: 'Deep midnight obsidian with hand-burnished 24K gold accents and warm amber luminescence',
    swatchColors: ['#070A0F', '#D4AF37', '#FEF08A'],
    viewportBg: '#070A0F',
    gridStroke: '#334155',
    gridOpacity: 0.22,
    outerWallStroke: '#D4AF37',
    defaultRoomFill: '#111726',
    defaultRoomStroke: '#1E293B',
    selectedRoomFill: '#D4AF37',
    selectedRoomStroke: '#FDE047',
    roomTextColor: '#F8FAFC',
    roomSubTextColor: '#FEF08A',
    accentColor: '#D4AF37',
    pinColor: '#F59E0B',
    badgeBg: 'rgba(212, 175, 55, 0.12)',
    badgeBorder: 'rgba(212, 175, 55, 0.4)',
    badgeText: '#FDE047',
    glowColor: 'rgba(212, 175, 55, 0.35)',
  },
  'blueprint': {
    id: 'blueprint',
    name: 'Technical CAD Cobalt',
    shortName: 'CAD Blue',
    tagline: 'Precision engineering cyan linework over structural cobalt architectural drafting grid',
    swatchColors: ['#030D1C', '#0284c7', '#38bdf8'],
    viewportBg: '#030D1C',
    gridStroke: '#0284c7',
    gridOpacity: 0.28,
    outerWallStroke: '#38bdf8',
    defaultRoomFill: '#061730',
    defaultRoomStroke: '#0369a1',
    selectedRoomFill: '#0284c7',
    selectedRoomStroke: '#38bdf8',
    roomTextColor: '#e0f2fe',
    roomSubTextColor: '#7dd3fc',
    accentColor: '#38bdf8',
    pinColor: '#00F0FF',
    badgeBg: 'rgba(56, 189, 248, 0.12)',
    badgeBorder: 'rgba(56, 189, 248, 0.4)',
    badgeText: '#7DD3FC',
    glowColor: 'rgba(56, 189, 248, 0.35)',
  },
  'nordic-ivory': {
    id: 'nordic-ivory',
    name: 'Nordic Ivory & Light Oak',
    shortName: 'Nordic Ivory',
    tagline: 'Warm Scandinavian parchment tones with light travertine fills and matte graphite borders',
    swatchColors: ['#F6F3ED', '#D4A373', '#0F172A'],
    viewportBg: '#F6F3ED',
    gridStroke: '#CBD5E1',
    gridOpacity: 0.5,
    outerWallStroke: '#0F172A',
    defaultRoomFill: '#EDE7DC',
    defaultRoomStroke: '#94A3B8',
    selectedRoomFill: '#D4A373',
    selectedRoomStroke: '#0F172A',
    roomTextColor: '#0F172A',
    roomSubTextColor: '#475569',
    accentColor: '#B45309',
    pinColor: '#B45309',
    badgeBg: 'rgba(180, 83, 9, 0.12)',
    badgeBorder: 'rgba(180, 83, 9, 0.35)',
    badgeText: '#92400E',
    glowColor: 'rgba(212, 163, 115, 0.4)',
  },
  'vastu-mandala': {
    id: 'vastu-mandala',
    name: 'Vedic Vastu Mandala Grid',
    shortName: 'Vastu Mandala',
    tagline: 'Sacred 9-quadrant directional energy zoning with Ishanya (NE), Agneya (SE), and central Brahmāsthan',
    swatchColors: ['#060A14', '#10B981', '#F59E0B'],
    viewportBg: '#060A14',
    gridStroke: '#D4AF37',
    gridOpacity: 0.3,
    outerWallStroke: '#F59E0B',
    defaultRoomFill: '#0D1424',
    defaultRoomStroke: '#334155',
    selectedRoomFill: '#F59E0B',
    selectedRoomStroke: '#FEF08A',
    roomTextColor: '#FFFFFF',
    roomSubTextColor: '#FDE047',
    accentColor: '#F59E0B',
    pinColor: '#10B981',
    badgeBg: 'rgba(245, 158, 11, 0.12)',
    badgeBorder: 'rgba(245, 158, 11, 0.4)',
    badgeText: '#FDE047',
    glowColor: 'rgba(245, 158, 11, 0.35)',
  },
  'emerald-sanctuary': {
    id: 'emerald-sanctuary',
    name: 'Emerald Biophilic Sanctuary',
    shortName: 'Emerald Forest',
    tagline: 'Deep rainforest emerald with botanical sage highlights and warm polished brass accents',
    swatchColors: ['#04140D', '#059669', '#34D399'],
    viewportBg: '#04140D',
    gridStroke: '#059669',
    gridOpacity: 0.25,
    outerWallStroke: '#10B981',
    defaultRoomFill: '#072418',
    defaultRoomStroke: '#065F46',
    selectedRoomFill: '#059669',
    selectedRoomStroke: '#6EE7B7',
    roomTextColor: '#ECFDF5',
    roomSubTextColor: '#A7F3D0',
    accentColor: '#10B981',
    pinColor: '#34D399',
    badgeBg: 'rgba(16, 185, 129, 0.12)',
    badgeBorder: 'rgba(16, 185, 129, 0.4)',
    badgeText: '#6EE7B7',
    glowColor: 'rgba(16, 185, 129, 0.35)',
  },
  'champagne-rose': {
    id: 'champagne-rose',
    name: 'Champagne Rose & Warm Bronze',
    shortName: 'Champagne Rose',
    tagline: 'Blush metallic rose copper and warm burnished bronze for ultra-contemporary elegance',
    swatchColors: ['#120A0E', '#E0A99E', '#FB7185'],
    viewportBg: '#120A0E',
    gridStroke: '#881337',
    gridOpacity: 0.24,
    outerWallStroke: '#FB7185',
    defaultRoomFill: '#1E1218',
    defaultRoomStroke: '#4C1D2B',
    selectedRoomFill: '#E0A99E',
    selectedRoomStroke: '#FECDD3',
    roomTextColor: '#FFF1F2',
    roomSubTextColor: '#FFE4E6',
    accentColor: '#FB7185',
    pinColor: '#FDA4AF',
    badgeBg: 'rgba(251, 113, 133, 0.12)',
    badgeBorder: 'rgba(251, 113, 133, 0.4)',
    badgeText: '#FECDD3',
    glowColor: 'rgba(251, 113, 133, 0.35)',
  },
  'monochrome-platinum': {
    id: 'monochrome-platinum',
    name: 'Monochrome Platinum & Graphite',
    shortName: 'Platinum Graphite',
    tagline: 'Architectural minimalism with graphite tones, platinum silver outlines, and crisp high contrast',
    swatchColors: ['#0A0A0C', '#E2E8F0', '#94A3B8'],
    viewportBg: '#0A0A0C',
    gridStroke: '#475569',
    gridOpacity: 0.22,
    outerWallStroke: '#E2E8F0',
    defaultRoomFill: '#181A20',
    defaultRoomStroke: '#334155',
    selectedRoomFill: '#64748B',
    selectedRoomStroke: '#F8FAFC',
    roomTextColor: '#F8FAFC',
    roomSubTextColor: '#E2E8F0',
    accentColor: '#E2E8F0',
    pinColor: '#FFFFFF',
    badgeBg: 'rgba(226, 232, 240, 0.12)',
    badgeBorder: 'rgba(226, 232, 240, 0.4)',
    badgeText: '#F8FAFC',
    glowColor: 'rgba(226, 232, 240, 0.35)',
  },
};

export interface MaterialSwatch {
  id: string;
  name: string;
  category: string;
  application: string;
  origin: string;
  finish: string;
  imageUrl: string;
}

export const LUXURY_MATERIAL_SWATCHES: MaterialSwatch[] = [
  {
    id: 'mat-botticino',
    name: 'Italian Botticino Classico Marble',
    category: 'Flooring',
    application: 'Living, Dining & Foyer',
    origin: 'Brescia, Italy',
    finish: 'Mirror Polished Bookmatched Slabs',
    imageUrl: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=600&q=80',
  },
  {
    id: 'mat-oak',
    name: 'European Smoked Natural Oak',
    category: 'Master Suite Flooring',
    application: 'Bedrooms & Private Suites',
    origin: 'Black Forest, Germany',
    finish: 'Wire-Brushed Matte UV Lacquered',
    imageUrl: 'https://images.unsplash.com/photo-1600566753190-17f0baa2a6c3?auto=format&fit=crop&w=600&q=80',
  },
  {
    id: 'mat-brass',
    name: 'Jaquar Artize Brushed Champagne Brass',
    category: 'Sanitary & Hardware',
    application: 'Ensuite Bathrooms & Doorware',
    origin: 'Jaquar Signature Atelier',
    finish: 'PVD Vapor Deposited Matte Brass',
    imageUrl: 'https://images.unsplash.com/photo-1600573472592-401b489a3cdc?auto=format&fit=crop&w=600&q=80',
  },
  {
    id: 'mat-quartz',
    name: 'Calacatta Gold Pure Quartz',
    category: 'Kitchen Worktops',
    application: 'Kitchen Island & Breakfast Bar',
    origin: 'Spain',
    finish: 'Anti-Microbial Honed Silk Finish',
    imageUrl: 'https://images.unsplash.com/photo-1600585154526-990dced4db0d?auto=format&fit=crop&w=600&q=80',
  },
  {
    id: 'mat-teak',
    name: 'Burma Teak Decking',
    category: 'Outdoor Terraces',
    application: 'Sky Balconies & Rooftop Pergolas',
    origin: 'Sustainably Harvested Teak',
    finish: 'Marine Weather-Sealed Natural Oil',
    imageUrl: 'https://images.unsplash.com/photo-1616137466211-f939a420be84?auto=format&fit=crop&w=600&q=80',
  },
  {
    id: 'mat-makrana',
    name: 'Sacred Makrana Pure White Marble',
    category: 'Prayer Sanctum',
    application: 'Vastu Mandir Alcove & Jaali Screen',
    origin: 'Makrana, Rajasthan',
    finish: 'Hand-Chiseled Lattice Craftsmanship',
    imageUrl: 'https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?auto=format&fit=crop&w=600&q=80',
  },
];

export interface RoomPhotoGalleryItem {
  id: string;
  roomId: string;
  planId: string;
  title: string;
  mood: 'daylight' | 'twilight' | 'finishes';
  label: string;
  imageUrl: string;
  specs: string;
}

export const ROOM_PHOTOGRAPHY: Record<string, {
  daylight: string;
  twilight: string;
  finishes: string;
  caption: string;
}> = {
  // 2 BHK Urban Luxury Residence Spaces
  'room-2bhk-living': {
    daylight: 'https://images.unsplash.com/photo-1554995207-c18c203602cb?auto=format&fit=crop&w=1200&q=80',
    twilight: 'https://images.unsplash.com/photo-1512915922686-57c11dde9b6b?auto=format&fit=crop&w=1200&q=80',
    finishes: 'https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?auto=format&fit=crop&w=1200&q=80',
    caption: 'Sunlit 2 BHK urban living lounge with porcelain glazed tiles (800×1600mm) and sliding full-height terrace doors.',
  },
  'room-2bhk-master': {
    daylight: 'https://images.unsplash.com/photo-1598928506311-c55ded91a20c?auto=format&fit=crop&w=1200&q=80',
    twilight: 'https://images.unsplash.com/photo-1505693416388-ac5ce068fe85?auto=format&fit=crop&w=1200&q=80',
    finishes: 'https://images.unsplash.com/photo-1616486338812-3dadae4b4ace?auto=format&fit=crop&w=1200&q=80',
    caption: 'Acoustically isolated master suite with warm European laminated flooring, recessed reading sconces, and garden views.',
  },
  'room-2bhk-kitchen': {
    daylight: 'https://images.unsplash.com/photo-1556911220-e15b29be8c8f?auto=format&fit=crop&w=1200&q=80',
    twilight: 'https://images.unsplash.com/photo-1507652313519-d4e9174996dd?auto=format&fit=crop&w=1200&q=80',
    finishes: 'https://images.unsplash.com/photo-1600585154526-990dced4db0d?auto=format&fit=crop&w=1200&q=80',
    caption: 'Contemporary streamlined modular kitchen with black granite counters, Blum soft-close fittings, and dedicated utility.',
  },
  'room-2bhk-balcony': {
    daylight: 'https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=1200&q=80',
    twilight: 'https://images.unsplash.com/photo-1616137466211-f939a420be84?auto=format&fit=crop&w=1200&q=80',
    finishes: 'https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?auto=format&fit=crop&w=1200&q=80',
    caption: 'Sunrise balcony with wooden ceramic floor tiles, tempered glass railing, and botanical planters.',
  },
  'room-2bhk-bed2': {
    daylight: 'https://images.unsplash.com/photo-1595526114035-0d45ed16cfbf?auto=format&fit=crop&w=1200&q=80',
    twilight: 'https://images.unsplash.com/photo-1600566753190-17f0baa2a6c3?auto=format&fit=crop&w=1200&q=80',
    finishes: 'https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?auto=format&fit=crop&w=1200&q=80',
    caption: 'Multifunctional guest bedroom & home office study alcove with natural morning daylighting.',
  },
  'room-2bhk-mandir': {
    daylight: 'https://images.unsplash.com/photo-1582560475093-ba66accbc424?auto=format&fit=crop&w=1200&q=80',
    twilight: 'https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=1200&q=80',
    finishes: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1200&q=80',
    caption: 'Vastu Ishanya prayer sanctuary alcove crafted with pure Makrana white marble stone.',
  },

  // 3 BHK Signature Ultra-Luxury Spaces
  'room-living': {
    daylight: 'https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?auto=format&fit=crop&w=1200&q=80',
    twilight: 'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?auto=format&fit=crop&w=1200&q=80',
    finishes: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1200&q=80',
    caption: 'Double-height 26-ft living salon with bookmatched Italian Botticino marble and expansive sliding glass opening to the terrace.',
  },
  'room-master': {
    daylight: 'https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?auto=format&fit=crop&w=1200&q=80',
    twilight: 'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?auto=format&fit=crop&w=1200&q=80',
    finishes: 'https://images.unsplash.com/photo-1616486338812-3dadae4b4ace?auto=format&fit=crop&w=1200&q=80',
    caption: 'South-West master sanctuary featuring fluted oak acoustic wall panels and floor-to-ceiling panoramic sunset glazing.',
  },
  'room-kitchen': {
    daylight: 'https://images.unsplash.com/photo-1600585154526-990dced4db0d?auto=format&fit=crop&w=1200&q=80',
    twilight: 'https://images.unsplash.com/photo-1556911220-e15b29be8c8f?auto=format&fit=crop&w=1200&q=80',
    finishes: 'https://images.unsplash.com/photo-1507652313519-d4e9174996dd?auto=format&fit=crop&w=1200&q=80',
    caption: 'European culinary center equipped with Calacatta quartz countertops, concealed Blum soft-close fittings, and task LEDs.',
  },
  'room-balcony': {
    daylight: 'https://images.unsplash.com/photo-1616137466211-f939a420be84?auto=format&fit=crop&w=1200&q=80',
    twilight: 'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&w=1200&q=80',
    finishes: 'https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?auto=format&fit=crop&w=1200&q=80',
    caption: 'Cantilevered sky balcony with weather-sealed teakwood decking, frameless glass balustrade, and planter drip irrigation.',
  },
  'room-bed2': {
    daylight: 'https://images.unsplash.com/photo-1595526114035-0d45ed16cfbf?auto=format&fit=crop&w=1200&q=80',
    twilight: 'https://images.unsplash.com/photo-1505693416388-ac5ce068fe85?auto=format&fit=crop&w=1200&q=80',
    finishes: 'https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?auto=format&fit=crop&w=1200&q=80',
    caption: 'Junior suite with corner floor-to-ceiling windows, engineered parquet, and integrated executive study alcove.',
  },
  'room-mandir': {
    daylight: 'https://images.unsplash.com/photo-1582560475093-ba66accbc424?auto=format&fit=crop&w=1200&q=80',
    twilight: 'https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=1200&q=80',
    finishes: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1200&q=80',
    caption: 'Sacred Ishanya mandir sanctuary crafted from pure Makrana marble with delicate jaali stone lattice and warm brass glow.',
  },

  // 4 BHK Sky Mansion Penthouse Spaces
  'room-ph-living': {
    daylight: 'https://images.unsplash.com/photo-1600566753376-12c8ab7fb75b?auto=format&fit=crop&w=1200&q=80',
    twilight: 'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?auto=format&fit=crop&w=1200&q=80',
    finishes: 'https://images.unsplash.com/photo-1616486338812-3dadae4b4ace?auto=format&fit=crop&w=1200&q=80',
    caption: 'Presidential 32-ft ballroom salon with double-height ceiling, bookmatched Statuario marble, and private elevator vestibule.',
  },
  'room-ph-master': {
    daylight: 'https://images.unsplash.com/photo-1600566753190-17f0baa2a6c3?auto=format&fit=crop&w=1200&q=80',
    twilight: 'https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?auto=format&fit=crop&w=1200&q=80',
    finishes: 'https://images.unsplash.com/photo-1600573472592-401b489a3cdc?auto=format&fit=crop&w=1200&q=80',
    caption: 'Presidential master retreat with walk-in dressing salon, ensuite spa bath, and private terrace access.',
  },
  'room-ph-terrace': {
    daylight: 'https://images.unsplash.com/photo-1540555700478-4be289fbecef?auto=format&fit=crop&w=1200&q=80',
    twilight: 'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&w=1200&q=80',
    finishes: 'https://images.unsplash.com/photo-1616137466211-f939a420be84?auto=format&fit=crop&w=1200&q=80',
    caption: '380 sq. ft. private sky deck with plunge pool provision, sunset horizon views, and automated louvers.',
  },
};

// High-resolution 3D Top-Down Cutaway Renders for each Floor Plan
export const PLAN_3D_CUTAWAY_IMAGES: Record<string, {
  renderUrl: string;
  blueprintSketchUrl: string;
  isometricAngleUrl: string;
  caption: string;
}> = {
  'fp-2bhk-fortune': {
    renderUrl: 'https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?auto=format&fit=crop&w=1600&q=85',
    blueprintSketchUrl: 'https://images.unsplash.com/photo-1503387762-592deb58ef4e?auto=format&fit=crop&w=1600&q=85',
    isometricAngleUrl: 'https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?auto=format&fit=crop&w=1600&q=85',
    caption: 'Photorealistic 3D architectural cutaway of Vedira 2 BHK (1,420 sq. ft.) featuring open-plan living lounge, compact gourmet kitchen, and sunrise balcony.',
  },
  'fp-3bhk-fortune': {
    renderUrl: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1600&q=85',
    blueprintSketchUrl: 'https://images.unsplash.com/photo-1524758631624-e2822e304c36?auto=format&fit=crop&w=1600&q=85',
    isometricAngleUrl: 'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?auto=format&fit=crop&w=1600&q=85',
    caption: 'Photorealistic 3D rendered cutaway of Vedira Fortune 3 BHK (2,097 sq. ft.) showcasing open-plan living, Italian marble, and east garden terrace.',
  },
  'fp-4bhk-penthouse': {
    renderUrl: 'https://images.unsplash.com/photo-1600607687920-4e2a09cf159d?auto=format&fit=crop&w=1600&q=85',
    blueprintSketchUrl: 'https://images.unsplash.com/photo-1507652313519-d4e9174996dd?auto=format&fit=crop&w=1600&q=85',
    isometricAngleUrl: 'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&w=1600&q=85',
    caption: 'Full-floor Sky Mansion Penthouse 3D render (2,850 sq. ft.) with dual wrap-around sky terraces and presidential master retreat.',
  },
  'fp-vh-4bhk': {
    renderUrl: 'https://images.unsplash.com/photo-1600566753376-12c8ab7fb75b?auto=format&fit=crop&w=1600&q=85',
    blueprintSketchUrl: 'https://images.unsplash.com/photo-1503387762-592deb58ef4e?auto=format&fit=crop&w=1600&q=85',
    isometricAngleUrl: 'https://images.unsplash.com/photo-1600566753190-17f0baa2a6c3?auto=format&fit=crop&w=1600&q=85',
    caption: 'Vedira Heights 4 BHK Grand Sky Suite 3D render (2,850 sq. ft.) featuring grand family saloon and double-aspect bedrooms.',
  },
  'fp-rb-3bhk': {
    renderUrl: 'https://images.unsplash.com/photo-1600585154526-990dced4db0d?auto=format&fit=crop&w=1600&q=85',
    blueprintSketchUrl: 'https://images.unsplash.com/photo-1507652313519-d4e9174996dd?auto=format&fit=crop&w=1600&q=85',
    isometricAngleUrl: 'https://images.unsplash.com/photo-1616486338812-3dadae4b4ace?auto=format&fit=crop&w=1600&q=85',
    caption: 'Ramalaya Bliss ready-to-move 3 BHK residence (1,980 sq. ft.) with vitrified flooring and east-facing balcony.',
  },
  'fp-gk-plot': {
    renderUrl: 'https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=1600&q=85',
    blueprintSketchUrl: 'https://images.unsplash.com/photo-1503387762-592deb58ef4e?auto=format&fit=crop&w=1600&q=85',
    isometricAngleUrl: 'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&w=1600&q=85',
    caption: 'Gurukul Township 2,400 sq. ft. master villa plot schematic with RL sanctioned construction footprint.',
  },
  'fp-va-suite': {
    renderUrl: 'https://images.unsplash.com/photo-1497366216548-37526070297c?auto=format&fit=crop&w=1600&q=85',
    blueprintSketchUrl: 'https://images.unsplash.com/photo-1503387762-592deb58ef4e?auto=format&fit=crop&w=1600&q=85',
    isometricAngleUrl: 'https://images.unsplash.com/photo-1497215728101-856f4ea42174?auto=format&fit=crop&w=1600&q=85',
    caption: 'Vedmay Avenue One Grade-A commercial office suite (1,850 sq. ft.) column-free layout with executive cabin and conference zone.',
  },
};

// Explicit High-Resolution Architectural Snapshot Model for 2BHK, 3BHK, 4BHK
export interface BhkArchitecturalSnapshot {
  bhk: '2BHK' | '3BHK' | '4BHK';
  badge: string;
  title: string;
  subtitle: string;
  planId: string;
  superBuiltUp: string;
  carpetArea: string;
  balconyArea: string;
  priceEstimate: string;
  vastuScore: number;
  description: string;
  hero3DCutaway: string;
  isometricAngle: string;
  blueprintSketch: string;
  daylightView: string;
  twilightView: string;
  livingLounge: string;
  masterSuite: string;
  kitchenDining: string;
  balconyTerrace: string;
  caption: string;
  specs: string[];
}

export const BHK_ARCHITECTURAL_SNAPSHOTS: Record<'2BHK' | '3BHK' | '4BHK', BhkArchitecturalSnapshot> = {
  '2BHK': {
    bhk: '2BHK',
    badge: 'Compact Luxury Urban Suite',
    title: '2 BHK Urban Luxury Residence',
    subtitle: 'Streamlined Ergonomics & Sunlit Cross-Ventilated Spatial Design',
    planId: 'fp-2bhk-fortune',
    superBuiltUp: '1,420 sq. ft.',
    carpetArea: '1,080 sq. ft.',
    balconyArea: '140 sq. ft.',
    priceEstimate: '₹98 Lakh onwards',
    vastuScore: 100,
    description:
      'Bespoke 2 BHK architectural plan crafted for contemporary urbanites, featuring 100% Vastu compliance, porcelain floor tiles (800×1600mm), private sunlit balcony, smart modular kitchen, and an acoustically insulated master bedroom suite.',
    hero3DCutaway: 'https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?auto=format&fit=crop&w=1600&q=85',
    isometricAngle: 'https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?auto=format&fit=crop&w=1600&q=85',
    blueprintSketch: 'https://images.unsplash.com/photo-1503387762-592deb58ef4e?auto=format&fit=crop&w=1600&q=85',
    daylightView: 'https://images.unsplash.com/photo-1554995207-c18c203602cb?auto=format&fit=crop&w=1600&q=85',
    twilightView: 'https://images.unsplash.com/photo-1512915922686-57c11dde9b6b?auto=format&fit=crop&w=1600&q=85',
    livingLounge: 'https://images.unsplash.com/photo-1554995207-c18c203602cb?auto=format&fit=crop&w=1600&q=85',
    masterSuite: 'https://images.unsplash.com/photo-1598928506311-c55ded91a20c?auto=format&fit=crop&w=1600&q=85',
    kitchenDining: 'https://images.unsplash.com/photo-1556911220-e15b29be8c8f?auto=format&fit=crop&w=1600&q=85',
    balconyTerrace: 'https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=1600&q=85',
    caption: 'High-Res 2 BHK Architectural Snapshot (1,420 sq. ft.) featuring minimalist contemporary finishes and seamless flow.',
    specs: [
      'Glazed porcelain polished floor tiles (800mm × 1600mm)',
      'Concealed copper wiring with Schneider modular switches',
      'Granite kitchen counter with stainless steel sink & gas pipeline',
      'Laminated wooden flooring in master bedroom suite',
      'Toughened glass balcony railing with matte bronze cap',
    ],
  },
  '3BHK': {
    bhk: '3BHK',
    badge: 'Signature Ultra-Luxury Residence',
    title: '3 BHK Signature Ultra-Luxury Residence',
    subtitle: 'Grand 26-ft Living Salon & Dedicated Ishanya Vastu Prayer Sanctum',
    planId: 'fp-3bhk-fortune',
    superBuiltUp: '2,097 sq. ft.',
    carpetArea: '1,580 sq. ft.',
    balconyArea: '220 sq. ft.',
    priceEstimate: '₹1.45 Cr onwards',
    vastuScore: 100,
    description:
      'Flagship 3 BHK spatial configuration in Vedira Fortune, boasting an expansive 26-ft living salon, bookmatched Italian Botticino marble, south-west master suite with walk-in closet, 2 panoramic sunrise balconies, and an authentic Ishanya Vastu Mandir.',
    hero3DCutaway: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1600&q=85',
    isometricAngle: 'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?auto=format&fit=crop&w=1600&q=85',
    blueprintSketch: 'https://images.unsplash.com/photo-1524758631624-e2822e304c36?auto=format&fit=crop&w=1600&q=85',
    daylightView: 'https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?auto=format&fit=crop&w=1600&q=85',
    twilightView: 'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?auto=format&fit=crop&w=1600&q=85',
    livingLounge: 'https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?auto=format&fit=crop&w=1600&q=85',
    masterSuite: 'https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?auto=format&fit=crop&w=1600&q=85',
    kitchenDining: 'https://images.unsplash.com/photo-1600585154526-990dced4db0d?auto=format&fit=crop&w=1600&q=85',
    balconyTerrace: 'https://images.unsplash.com/photo-1616137466211-f939a420be84?auto=format&fit=crop&w=1600&q=85',
    caption: 'High-Res 3 BHK Architectural Snapshot (2,097 sq. ft.) showcasing grand salon, Italian marble, and east sky garden.',
    specs: [
      'Italian Botticino Classico mirror-polished marble in living & dining',
      'German engineered smoked oak hardwood in master sanctuary',
      'Calacatta Gold quartz countertops with Blum soft-close fittings',
      'Jaquar Artize brushed champagne brass sanitary fittings',
      'Fingerprint digital biometric locks with mobile keyless access',
    ],
  },
  '4BHK': {
    bhk: '4BHK',
    badge: 'Sky Mansion Penthouse & Duplex',
    title: '4 BHK Sky Mansion Penthouse',
    subtitle: 'Full-Floor Grandeur with Wraparound Sky Deck & Plunge Pool Provision',
    planId: 'fp-4bhk-penthouse',
    superBuiltUp: '2,850 sq. ft.',
    carpetArea: '2,190 sq. ft.',
    balconyArea: '380 sq. ft.',
    priceEstimate: '₹2.45 Cr onwards',
    vastuScore: 98,
    description:
      'The pinnacle of high-rise luxury in Nagpur. Full-floor sky mansion boasting a 32-ft grand ballroom living salon, dual chef show kitchen and service butler pantry, presidential master suite with private dressing room, and a 380 sq. ft. sky deck with plunge pool provision.',
    hero3DCutaway: 'https://images.unsplash.com/photo-1600607687920-4e2a09cf159d?auto=format&fit=crop&w=1600&q=85',
    isometricAngle: 'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&w=1600&q=85',
    blueprintSketch: 'https://images.unsplash.com/photo-1507652313519-d4e9174996dd?auto=format&fit=crop&w=1600&q=85',
    daylightView: 'https://images.unsplash.com/photo-1600566753376-12c8ab7fb75b?auto=format&fit=crop&w=1600&q=85',
    twilightView: 'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?auto=format&fit=crop&w=1600&q=85',
    livingLounge: 'https://images.unsplash.com/photo-1600566753376-12c8ab7fb75b?auto=format&fit=crop&w=1600&q=85',
    masterSuite: 'https://images.unsplash.com/photo-1600566753190-17f0baa2a6c3?auto=format&fit=crop&w=1600&q=85',
    kitchenDining: 'https://images.unsplash.com/photo-1600488999268-245f36e4f9b8?auto=format&fit=crop&w=1600&q=85',
    balconyTerrace: 'https://images.unsplash.com/photo-1540555700478-4be289fbecef?auto=format&fit=crop&w=1600&q=85',
    caption: 'High-Res 4 BHK Architectural Snapshot (2,850 sq. ft.) featuring full-floor sky mansion layout, private terrace & plunge pool.',
    specs: [
      'Bookmatched Statuario Italian marble with custom geometric brass transitions',
      'Direct private keycard elevator landing directly into residential foyer',
      'Full-floor panoramic acoustic glazing with UV reflective low-E coating',
      'Dual master suites with custom nubuck leather & fluted walnut panelling',
      '380 sq. ft. private sunset sky terrace with plunge pool provision',
    ],
  },
};

