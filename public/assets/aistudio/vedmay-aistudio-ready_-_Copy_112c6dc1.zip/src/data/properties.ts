export interface RoomDetail {
  id: string;
  name: string;
  dimensions: string;
  sqft: number;
  sqm: number;
  vastuQuadrant: string;
  finishes: string;
  lighting: string;
  coordinates: { x: number; y: number; width: number; height: number };
}

export interface FloorPlanOption {
  id: string;
  title: string;
  config: string;
  superBuiltUpSqFt: number;
  carpetSqFt: number;
  balconySqFt: number;
  vastuScore: number;
  facing: string;
  description: string;
  rooms: RoomDetail[];
}

export interface GalleryItem {
  id: string;
  caption: string;
  category: 'Exterior' | 'Living Room' | 'Master Suite' | 'Terrace Deck' | 'Kitchen' | 'Amenities';
  aspectRatio: string;
  image: string;
}

export interface Property {
  id: string;
  title: string;
  subtitle: string;
  category: 'ultra-luxury-flats' | 'sky-mansions' | 'plotted-enclaves' | 'commercial';
  tabCategories: ('featured' | 'new-launches' | 'communities' | 'ready-to-move' | 'commercial')[];
  location: string;
  city: string;
  priceStartingFrom: number;
  priceDisplay: string;
  configurations: string[];
  carpetAreaRange: string;
  status: 'Ready to Move' | 'Under Construction' | 'New Launch';
  statusKicker?: string;
  completionDate: string;
  reraNumber: string;
  image: string;
  highlightSpecs: string[];
  description: string;
  features: {
    vastuCompliant: boolean;
    evCharging: boolean;
    solarGrid: boolean;
    biometricSecurity: boolean;
    terraceGazebo: boolean;
    rainwaterHarvesting: boolean;
  };
  gallery: GalleryItem[];
  floorPlans: FloorPlanOption[];
}

export const PROPERTIES: Property[] = [
  {
    id: 'vedira-fortune',
    title: 'Vedira Fortune',
    subtitle: '3 BHK Ultra Luxury Flats in Nagpur',
    category: 'ultra-luxury-flats',
    tabCategories: ['featured', 'new-launches'],
    statusKicker: 'Possession Started',
    location: 'New Manish Nagar / Somalwada',
    city: 'Nagpur',
    priceStartingFrom: 14500000,
    priceDisplay: '₹1.45 Cr onwards',
    configurations: ['2 BHK Ultra-Luxury', '3 BHK Sky Residence', '4 BHK Duplex Penthouse'],
    carpetAreaRange: '1,420 - 2,850 sq. ft.',
    status: 'Under Construction',
    completionDate: 'December 2026',
    reraNumber: 'P50500049281',
    image: '/images/vedmay/vedira-fortune-main.png',
    highlightSpecs: [
      '3 BHK Ultra-Luxury Flats crafted for elegance and modern convenience',
      'Thumb-print biometric digital door locks & smart video door security',
      '5kW common solar grid system powering all common utilities',
      'Dedicated EV vehicle fast-charging stations in stilt parking',
      'Rooftop gazebo lounge, sky garden & sunrise yoga deck',
      '100% Vastu-compliant layout designed by senior Vedic architects',
    ],
    description:
      'A signature landmark project by Vedmay Infra, Vedira Fortune redefines modern living with elegance and class. Located in the heart of Nagpur at New Manish Nagar / Somalwada, this premium residential project offers 3 BHK ultra luxury flats crafted for those who desire sophistication, comfort, and convenience. More than just a property, Vedira Fortune is a lifestyle.',
    features: {
      vastuCompliant: true,
      evCharging: true,
      solarGrid: true,
      biometricSecurity: true,
      terraceGazebo: true,
      rainwaterHarvesting: true,
    },
    gallery: [
      {
        id: 'vf-1',
        caption: 'Vedira Fortune - 3 BHK Ultra Luxury Architectural Facade',
        category: 'Exterior',
        aspectRatio: '16:9',
        image: '/images/vedmay/vedira-fortune-main.png',
      },
      {
        id: 'vf-2',
        caption: 'Detailed Architectural Elevation Perspective',
        category: 'Exterior',
        aspectRatio: '16:9',
        image: '/images/vedmay/vedira-fortune-elevation.png',
      },
      {
        id: 'vf-3',
        caption: 'Living & Dining Luxury Hall with Designer False Ceiling',
        category: 'Living Room',
        aspectRatio: '16:9',
        image: '/images/vedmay/flats-living.jpg',
      },
      {
        id: 'vf-4',
        caption: 'Master Bedroom Suite with Wooden Flooring Finish',
        category: 'Master Suite',
        aspectRatio: '16:9',
        image: '/images/vedmay/flats-bedroom.jpg',
      },
      {
        id: 'vf-5',
        caption: 'Contemporary Modular Kitchen with Granite Counter',
        category: 'Kitchen',
        aspectRatio: '16:9',
        image: '/images/vedmay/flats-kitchen.jpg',
      },
      {
        id: 'vf-6',
        caption: 'Cantilevered Sky Terrace & Open Air Balcony',
        category: 'Terrace Deck',
        aspectRatio: '16:9',
        image: '/images/vedmay/flats-terrace.jpg',
      },
      {
        id: 'vf-7',
        caption: 'Official Architectural Floor Plan & Layout Document',
        category: 'Amenities',
        aspectRatio: '16:9',
        image: '/images/vedmay/vedira-fortune-plan.png',
      },
      {
        id: 'vf-8',
        caption: 'Approved Strategic Location & Transit Connectivity Map',
        category: 'Amenities',
        aspectRatio: '16:9',
        image: '/images/vedmay/vedira-fortune-location.png',
      },
    ],
    floorPlans: [
      {
        id: 'fp-vf-3bhk',
        title: 'Signature 3 BHK Sky Residence',
        config: '3 Bed · 3 Bath · Powder Room · 2 Terraces',
        superBuiltUpSqFt: 2150,
        carpetSqFt: 1680,
        balconySqFt: 240,
        vastuScore: 98,
        facing: 'East Facing Entrance',
        description:
          'Triple exposure residence with cantilevered terrace garden, double-height living foyer, and servant quarter.',
        rooms: [
          {
            id: 'room-vf-foyer',
            name: 'Grand Entrance Foyer',
            dimensions: `8'6" × 6'4"`,
            sqft: 54,
            sqm: 5.0,
            vastuQuadrant: 'Ishanya (North-East)',
            finishes: 'Italian Botticino marble with brass inlay borders',
            lighting: 'Recessed warm architectural spot troffers 2700K',
            coordinates: { x: 30, y: 15, width: 70, height: 50 },
          },
          {
            id: 'room-vf-living',
            name: 'Living & Dining Pavilion',
            dimensions: `26'4" × 15'6"`,
            sqft: 408,
            sqm: 37.9,
            vastuQuadrant: 'East (Surya Mandalam)',
            finishes: 'Polished book-matched Statuario marble slabs',
            lighting: 'Linear magnetic track lighting & cove ambient halo',
            coordinates: { x: 105, y: 15, width: 180, height: 110 },
          },
          {
            id: 'room-vf-master',
            name: 'Primary Master Suite',
            dimensions: `18'0" × 14'6"`,
            sqft: 261,
            sqm: 24.2,
            vastuQuadrant: 'Nairutya (South-West)',
            finishes: 'Solid smoked chevron European oak planks',
            lighting: 'Concealed indirect headboard lighting & dual reading spots',
            coordinates: { x: 30, y: 70, width: 140, height: 110 },
          },
          {
            id: 'room-vf-kitchen',
            name: 'Modular Gourmet Kitchen',
            dimensions: `14'0" × 10'6"`,
            sqft: 147,
            sqm: 13.6,
            vastuQuadrant: 'Agneya (South-East)',
            finishes: 'Silestone quartz counters with Blum soft-close cabinetry',
            lighting: 'High-CRI 95 task illumination over prep zones',
            coordinates: { x: 290, y: 15, width: 100, height: 85 },
          },
        ],
      },
    ],
  },
  {
    id: 'om-shree-estate',
    title: 'Om Shree Estate',
    subtitle: 'Prestigious Gated Plotted Community & Urban Living',
    category: 'plotted-enclaves',
    tabCategories: ['featured', 'communities', 'new-launches'],
    statusKicker: 'Possession Started',
    location: 'Prime Nagpur Growth Corridor, Maharashtra',
    city: 'Nagpur',
    priceStartingFrom: 5500000,
    priceDisplay: '₹55 Lakh onwards',
    configurations: ['1,500 sq. ft. Residential Plot', '2,500 sq. ft. Corner Villa Plot', '4,000 sq. ft. Estate Plot'],
    carpetAreaRange: '1,500 - 4,500 sq. ft.',
    status: 'Under Construction',
    completionDate: 'Possession Started',
    reraNumber: 'P50500051280',
    image: '/images/vedmay/om-shree-estate-main.jpg',
    highlightSpecs: [
      'Prestigious ongoing landmark project designed to set new standards in urban living',
      'Combines innovative design, superior quality, and unmatched convenience',
      'Sanctioned layout by NMRDA / NMC with RL and clear litigation-free title',
      'Wide concrete tree-lined avenues with underground electrical and drainage cabling',
      'Grand architectural entrance gate and boundary wall security',
      'Strategic location with fast highway access to Nagpur city center',
    ],
    description:
      'Om Shree Estate is our prestigious ongoing project designed to set new standards in urban living. Located in a prime area of Nagpur, this project combines innovative design, superior quality, and unmatched convenience to offer an exceptional residential experience. A landmark development by Vedmay Infra, blending innovation, quality, and trust.',
    features: {
      vastuCompliant: true,
      evCharging: true,
      solarGrid: true,
      biometricSecurity: true,
      terraceGazebo: false,
      rainwaterHarvesting: true,
    },
    gallery: [
      {
        id: 'os-1',
        caption: 'Om Shree Estate - Full Sanctioned Master Layout Plan',
        category: 'Exterior',
        aspectRatio: '16:9',
        image: '/images/vedmay/om-shree-estate-main.jpg',
      },
      {
        id: 'os-2',
        caption: 'Official Sanctioned Map with Plot Number Demarcations',
        category: 'Exterior',
        aspectRatio: '16:9',
        image: '/images/vedmay/om-shree-map.png',
      },
      {
        id: 'os-3',
        caption: 'Grand Entrance Gatehouse & Boundary Wall Arch',
        category: 'Exterior',
        aspectRatio: '16:9',
        image: '/images/vedmay/om-shree-estate-gate.jpg',
      },
      {
        id: 'os-4',
        caption: 'Actual On-Site Development, Asphalt Roads & Electrification',
        category: 'Amenities',
        aspectRatio: '16:9',
        image: '/images/vedmay/om-shree-estate-site.jpg',
      },
    ],
    floorPlans: [
      {
        id: 'fp-os-plot',
        title: 'Om Shree Estate - Villa Plot (2,500 sq. ft.)',
        config: '50ft × 50ft · NMRDA Sanctioned · Clear Title',
        superBuiltUpSqFt: 2500,
        carpetSqFt: 2500,
        balconySqFt: 0,
        vastuScore: 100,
        facing: 'East-Facing Wide Road',
        description: 'Prime rectangular villa plot ready for immediate custom bungalow construction.',
        rooms: [
          {
            id: 'room-os-footprint',
            name: 'Villa Building Envelope',
            dimensions: `35'0" × 40'0"`,
            sqft: 1400,
            sqm: 130.0,
            vastuQuadrant: 'Central Brahmasthan',
            finishes: 'Levelled ground with boundary markers and utility taps',
            lighting: 'All-day open sky natural illumination',
            coordinates: { x: 50, y: 50, width: 280, height: 200 },
          },
        ],
      },
    ],
  },
  {
    id: 'sai-nagri-9',
    title: 'Sai Nagri 9',
    subtitle: 'Strategic Residential & Villa Plotted Enclave',
    category: 'plotted-enclaves',
    tabCategories: ['communities', 'ready-to-move'],
    statusKicker: 'Possession Started',
    location: 'Borekhedi, Nagpur Growth Corridor',
    city: 'Nagpur',
    priceStartingFrom: 3800000,
    priceDisplay: '₹38 Lakh onwards',
    configurations: ['1,200 sq. ft. Plot', '1,800 sq. ft. Villa Plot', '3,200 sq. ft. Estate Plot'],
    carpetAreaRange: '1,200 - 3,200 sq. ft.',
    status: 'Ready to Move',
    completionDate: 'Possession Started',
    reraNumber: 'P50500048991',
    image: '/images/vedmay/sai-nagri-9-main.png',
    highlightSpecs: [
      'Strategically located in thriving Borekhedi along Nagpur industrial corridor',
      'Perfect blend of modern lifestyle and serene green surroundings',
      'Clear legal titles with full bank loan approvals available',
      'Demarcated individual plots with paved internal roads',
      'Overhead water supply & underground sewage system',
      'High growth investment potential with rapid area development',
    ],
    description:
      'Welcome to Sai Nagri 9, Borekhedi, a prestigious project by Vedmay Infra offering the perfect blend of modern lifestyle and serene surroundings. Strategically located in the thriving location of Borekhedi with possession already started, this project gives investors and homeowners unmatched value and peace of mind.',
    features: {
      vastuCompliant: true,
      evCharging: false,
      solarGrid: true,
      biometricSecurity: false,
      terraceGazebo: false,
      rainwaterHarvesting: true,
    },
    gallery: [
      {
        id: 'sn9-1',
        caption: 'Sai Nagri 9 - Masterplan & Community Visual',
        category: 'Exterior',
        aspectRatio: '16:9',
        image: '/images/vedmay/sai-nagri-9-main.png',
      },
      {
        id: 'sn9-2',
        caption: 'Sanctioned Layout Map with Highway Access',
        category: 'Exterior',
        aspectRatio: '16:9',
        image: '/images/vedmay/sai-nagri-9-layout.png',
      },
      {
        id: 'sn9-3',
        caption: 'Borekhedi Strategic Location Map & Surrounding Landmarks',
        category: 'Amenities',
        aspectRatio: '16:9',
        image: '/images/vedmay/sai-nagri-9-location.jpg',
      },
    ],
    floorPlans: [
      {
        id: 'fp-sn9-plot',
        title: 'Sai Nagri 9 - Residential Plot (1,800 sq. ft.)',
        config: '30ft × 60ft · North-East Facing · Ready for Construction',
        superBuiltUpSqFt: 1800,
        carpetSqFt: 1800,
        balconySqFt: 0,
        vastuScore: 96,
        facing: 'North-East Road',
        description: 'Ideal proportions for constructing a 3-storey private bungalow.',
        rooms: [
          {
            id: 'room-sn9-core',
            name: 'Plot Demarcation',
            dimensions: `30'0" × 60'0"`,
            sqft: 1800,
            sqm: 167.2,
            vastuQuadrant: 'North-East',
            finishes: 'Concrete boundary pegs with road frontage',
            lighting: 'Open daylight access',
            coordinates: { x: 60, y: 60, width: 260, height: 180 },
          },
        ],
      },
    ],
  },
  {
    id: 'sai-nagri-8',
    title: 'Sai Nagri 8',
    subtitle: 'Premium Residential Plots for Sale in Nagpur',
    category: 'plotted-enclaves',
    tabCategories: ['communities', 'new-launches'],
    statusKicker: 'Now Booking',
    location: 'Dongergaon, Nagpur',
    city: 'Nagpur',
    priceStartingFrom: 4200000,
    priceDisplay: '₹42 Lakh onwards',
    configurations: ['1,350 sq. ft. Plot', '2,100 sq. ft. Corner Plot', '3,500 sq. ft. Premium Plot'],
    carpetAreaRange: '1,350 - 3,500 sq. ft.',
    status: 'New Launch',
    completionDate: 'Phase 1 Ready',
    reraNumber: 'P50500052310',
    image: '/images/vedmay/sai-nagri-8-main.png',
    highlightSpecs: [
      'Thoughtfully planned project by Vedmay Infra in scenic Dongergaon',
      'Perfect harmony of tranquility, modernity, and nature',
      'Clear title sanction with instant registration and mutation',
      'Lush open garden reserves and senior citizens relaxation corner',
      'Wide concrete streets with LED streetlights throughout the layout',
      'Adjacent to flourishing Nagpur residential belt',
    ],
    description:
      'Discover Sai Nagri 8 – Premium Plots for Sale in Nagpur. Welcome to Sai Nagri 8, a thoughtfully planned project by Vedmay Infra that perfectly blends tranquility, modernity, and comfort. Located in the picturesque landscape of Dongergaon, this gated residential enclave offers titled plots with state-of-the-art civil infrastructure.',
    features: {
      vastuCompliant: true,
      evCharging: false,
      solarGrid: true,
      biometricSecurity: false,
      terraceGazebo: false,
      rainwaterHarvesting: true,
    },
    gallery: [
      {
        id: 'sn8-1',
        caption: 'Sai Nagri 8 - Premium Residential Plots Elevation',
        category: 'Exterior',
        aspectRatio: '16:9',
        image: '/images/vedmay/sai-nagri-8-main.png',
      },
      {
        id: 'sn8-2',
        caption: 'Complete Layout Scheme and Internal Road Network',
        category: 'Exterior',
        aspectRatio: '16:9',
        image: '/images/vedmay/sai-nagri-8-layout.png',
      },
      {
        id: 'sn8-3',
        caption: 'On-Site Development Progress & Tree Plantations',
        category: 'Amenities',
        aspectRatio: '16:9',
        image: '/images/vedmay/sai-nagri-8-site.png',
      },
    ],
    floorPlans: [
      {
        id: 'fp-sn8-plot',
        title: 'Sai Nagri 8 - Premium Villa Plot (2,100 sq. ft.)',
        config: '35ft × 60ft · Vastu Aligned · Direct Road Frontage',
        superBuiltUpSqFt: 2100,
        carpetSqFt: 2100,
        balconySqFt: 0,
        vastuScore: 97,
        facing: 'East Facing Road',
        description: 'Spacious corner villa plot in Dongergaon for building customized luxury homes.',
        rooms: [
          {
            id: 'room-sn8-bound',
            name: 'Villa Building Footprint',
            dimensions: `30'0" × 50'0"`,
            sqft: 1500,
            sqm: 139.3,
            vastuQuadrant: 'East & North',
            finishes: 'Levelled plot ready for immediate foundation work',
            lighting: 'Open panoramic daylighting',
            coordinates: { x: 50, y: 50, width: 270, height: 190 },
          },
        ],
      },
    ],
  },
  {
    id: 'sai-nagri-7',
    title: 'Sai Nagri 7',
    subtitle: 'Harmonious Living & Prime Titled Plots in Panchgaon',
    category: 'plotted-enclaves',
    tabCategories: ['communities', 'ready-to-move'],
    statusKicker: 'Possession Started',
    location: 'Panchgaon, Nagpur, Maharashtra',
    city: 'Nagpur',
    priceStartingFrom: 3500000,
    priceDisplay: '₹35 Lakh onwards',
    configurations: ['1,200 sq. ft. Plot', '1,650 sq. ft. Villa Plot', '2,800 sq. ft. Corner Plot'],
    carpetAreaRange: '1,200 - 2,800 sq. ft.',
    status: 'Ready to Move',
    completionDate: 'Possession Started',
    reraNumber: 'P50500047812',
    image: '/images/vedmay/sai-nagri-7-main.png',
    highlightSpecs: [
      'Remarkable project by Vedmay Infra offering modern living and natural serenity',
      'Located in thriving Panchgaon with swift access to central Nagpur',
      'Possession started with multiple families already beginning construction',
      'Underground electricity network, water supply lines & rainwater drainage',
      'Gated community layout with landscaped garden spaces',
      'High appreciation corridor adjoining major industrial and academic zones',
    ],
    description:
      'Welcome to Sai Nagri 7, a remarkable project by Vedmay Infra designed to offer a harmonious balance of modern living and natural serenity. Located in the thriving hub of Panchgaon, Nagpur, Sai Nagri 7 provides clear title residential plots ready for immediate villa construction.',
    features: {
      vastuCompliant: true,
      evCharging: false,
      solarGrid: true,
      biometricSecurity: false,
      terraceGazebo: false,
      rainwaterHarvesting: true,
    },
    gallery: [
      {
        id: 'sn7-1',
        caption: 'Sai Nagri 7 - Gated Plotted Community Presentation',
        category: 'Exterior',
        aspectRatio: '16:9',
        image: '/images/vedmay/sai-nagri-7-main.png',
      },
      {
        id: 'sn7-2',
        caption: 'Sanctioned Layout Map with Clear Demarcations',
        category: 'Exterior',
        aspectRatio: '16:9',
        image: '/images/vedmay/sai-nagri-7-layout.png',
      },
      {
        id: 'sn7-3',
        caption: 'Panchgaon Strategic Location Map and Road Connectivity',
        category: 'Amenities',
        aspectRatio: '16:9',
        image: '/images/vedmay/sai-nagri-7-location.jpg',
      },
    ],
    floorPlans: [
      {
        id: 'fp-sn7-plot',
        title: 'Sai Nagri 7 - Villa Plot (1,650 sq. ft.)',
        config: '30ft × 55ft · East-Facing · Clear Title',
        superBuiltUpSqFt: 1650,
        carpetSqFt: 1650,
        balconySqFt: 0,
        vastuScore: 99,
        facing: 'East-Facing Road',
        description: 'Prime rectangular residential plot with direct connection to wide internal road.',
        rooms: [
          {
            id: 'room-sn7-core',
            name: 'Villa Building Footprint',
            dimensions: `26'0" × 45'0"`,
            sqft: 1170,
            sqm: 108.7,
            vastuQuadrant: 'East & North-East',
            finishes: 'Boundary demarcated with concrete pillars',
            lighting: 'Open daylight access',
            coordinates: { x: 50, y: 50, width: 260, height: 180 },
          },
        ],
      },
    ],
  },
  {
    id: 'vedmay-flats-collection',
    title: 'Vedmay Signature Residences',
    subtitle: 'Completed Boutique Luxury Homes in Somalwada',
    category: 'ultra-luxury-flats',
    tabCategories: ['ready-to-move', 'featured'],
    statusKicker: 'Ready to Move',
    location: 'Somalwada Prime Enclave, Nagpur',
    city: 'Nagpur',
    priceStartingFrom: 12800000,
    priceDisplay: '₹1.28 Cr onwards',
    configurations: ['2 BHK Luxury Flat', '3 BHK Premium Residence'],
    carpetAreaRange: '1,180 - 1,980 sq. ft.',
    status: 'Ready to Move',
    completionDate: 'Ready for Immediate Possession',
    reraNumber: 'P50500045610',
    image: '/images/vedmay/flats-facade.jpg',
    highlightSpecs: [
      'Immediate possession with Occupancy Certificate (OC) issued',
      '100% legal title clearance and all major nationalized bank approvals',
      'Lush landscaped ground-level garden with senior citizen zone',
      'Covered reserved stilt parking for two vehicles per unit',
      'High-end branded CP fittings, false ceilings, and premium vitrified tiles',
      '6 mins to Airport South Metro Station and Wardha Road corridor',
    ],
    description:
      'Vedmay Signature Residences in Somalwada offer ready-to-move peace of mind. Constructed with uncompromising structural integrity, this boutique residential development has already welcomed discerning families who appreciate quiet elegance, neighborhood connectivity, and immaculate craftsmanship.',
    features: {
      vastuCompliant: true,
      evCharging: true,
      solarGrid: true,
      biometricSecurity: true,
      terraceGazebo: true,
      rainwaterHarvesting: true,
    },
    gallery: [
      {
        id: 'vfc-1',
        caption: 'Vedmay Completed Building Exterior Facade',
        category: 'Exterior',
        aspectRatio: '16:9',
        image: '/images/vedmay/flats-facade.jpg',
      },
      {
        id: 'vfc-2',
        caption: 'Building Facade at Night with Exterior Accent Lighting',
        category: 'Exterior',
        aspectRatio: '16:9',
        image: '/images/vedmay/flats-exterior.jpg',
      },
      {
        id: 'vfc-3',
        caption: 'Grand Entrance Gate & Gated Stilt Parking Access',
        category: 'Exterior',
        aspectRatio: '16:9',
        image: '/images/vedmay/flats-entrance.jpg',
      },
      {
        id: 'vfc-4',
        caption: 'Living Room Finished Interior with Designer False Ceiling',
        category: 'Living Room',
        aspectRatio: '16:9',
        image: '/images/vedmay/flats-living.jpg',
      },
      {
        id: 'vfc-5',
        caption: 'Spacious Master Bedroom Suite with Attached Bath',
        category: 'Master Suite',
        aspectRatio: '16:9',
        image: '/images/vedmay/flats-bedroom.jpg',
      },
      {
        id: 'vfc-6',
        caption: 'Modular Kitchen with Granite Countertops & Storage',
        category: 'Kitchen',
        aspectRatio: '16:9',
        image: '/images/vedmay/flats-kitchen.jpg',
      },
      {
        id: 'vfc-7',
        caption: 'Private Balcony with Open Panoramic Nagpur Skyline View',
        category: 'Terrace Deck',
        aspectRatio: '16:9',
        image: '/images/vedmay/flats-terrace.jpg',
      },
    ],
    floorPlans: [
      {
        id: 'fp-vfc-flat',
        title: '3 BHK Boutique Luxury Residence',
        config: '3 Bed · 3 Bath · 2 Balconies · Covered Stilt Car Parking',
        superBuiltUpSqFt: 1980,
        carpetSqFt: 1540,
        balconySqFt: 180,
        vastuScore: 99,
        facing: 'East Facing Entrance',
        description: 'Ready-to-move 3 BHK residence with premium fixtures and cross-ventilation.',
        rooms: [
          {
            id: 'room-vfc-hall',
            name: 'Living & Dining Room',
            dimensions: `22'0" × 14'0"`,
            sqft: 308,
            sqm: 28.6,
            vastuQuadrant: 'East (Surya Mandalam)',
            finishes: 'Double-charged vitrified tiles with false ceiling',
            lighting: 'Concealed LED warm ambient lighting',
            coordinates: { x: 80, y: 30, width: 220, height: 140 },
          },
        ],
      },
    ],
  },
  {
    id: 'vriddhi-icon',
    title: 'Vriddhi Icon Commercial Park',
    subtitle: 'Where Business Meets Growth — High-Street Showrooms & Corporate Offices',
    category: 'commercial',
    tabCategories: ['featured', 'new-launches', 'commercial'],
    statusKicker: 'Investor Proposal Open',
    location: 'Manish Nagar Main Road, near Ajit Bakery',
    city: 'Nagpur',
    priceStartingFrom: 50000000,
    priceDisplay: '₹5 Cr (Secured Investment • 30% Return)',
    configurations: [
      '2 High-Street Showrooms (Ground & 1st Floor)',
      '30 Corporate Office Suites (2nd to 6th Floor)',
      'Showroom 2 (6,543 sq ft super built-up collateral)',
    ],
    carpetAreaRange: '27,153 sq ft carpet · 55,041 sq ft super built-up',
    status: 'New Launch',
    completionDate: 'July 2028 (18-Month Term)',
    reraNumber: 'A50500037817',
    image: '/images/vedmay/vriddhi-icon/vriddhi-main-render.png',
    highlightSpecs: [
      'Prime 10,256 sq ft plot with 91 ft frontage on 60 ft Manish Nagar Main Road',
      'Two full basement parking floors + Ground + 6 upper commercial floors',
      'Double-glazed modern glass facade, dedicated generator power & rooftop solar',
      'Showroom 2 collateral valued at ₹14.73 Cr on completion (approx. 3x investment)',
      'Fixed 30% return over 18-month tenure (repaid ₹6.5 Cr in one payment)',
      'Promoted by Mr. Vicky Kachore — 10 years real estate leadership in Nagpur',
    ],
    description:
      'Vriddhi Icon Commercial Park is Vedmay Infra’s flagship commercial landmark on Manish Nagar Main Road, Nagpur. Featuring cutting-edge architectural glass facade, two large high-street retail showrooms on the ground and first floors, and 30 boutique office suites on the upper floors. Named after the founder’s daughter, Vriddhi symbolizes growth, prosperity, and an unyielding commitment to trust.',
    features: {
      vastuCompliant: true,
      evCharging: true,
      solarGrid: true,
      biometricSecurity: true,
      terraceGazebo: true,
      rainwaterHarvesting: true,
    },
    gallery: [
      {
        id: 'vi-1',
        caption: 'Vriddhi Icon Commercial Park — High-Rise Glass Facade & Corporate Frontage',
        category: 'Exterior',
        aspectRatio: '16:9',
        image: '/images/vedmay/vriddhi-icon/vriddhi-main-render.png',
      },
      {
        id: 'vi-2',
        caption: 'Architectural Glazing & Night Illumination on 60-Ft Manish Nagar Main Road',
        category: 'Exterior',
        aspectRatio: '16:9',
        image: '/images/vedmay/vriddhi-icon/vriddhi-facade.png',
      },
      {
        id: 'vi-3',
        caption: 'High-Street Retail Showroom Entrance & Double-Height Lobby',
        category: 'Exterior',
        aspectRatio: '16:9',
        image: '/images/vedmay/vriddhi-icon/vriddhi-showroom.png',
      },
      {
        id: 'vi-4',
        caption: 'Official Investor Proposal Cover — Where Business Meets Growth',
        category: 'Amenities',
        aspectRatio: '3:4',
        image: '/images/vedmay/vriddhi-icon/page-1.png',
      },
      {
        id: 'vi-5',
        caption: 'Project Specification & Architectural Perspective Sheet',
        category: 'Amenities',
        aspectRatio: '3:4',
        image: '/images/vedmay/vriddhi-icon/page-4.png',
      },
    ],
    floorPlans: [
      {
        id: 'fp-vriddhi-showroom',
        title: 'Showroom 2 (Ground & First Floor Duplex Retail)',
        config: '6,543 sq ft Super Built-Up · 2,991 sq ft Ground + 3,552 sq ft First Floor',
        superBuiltUpSqFt: 6543,
        carpetSqFt: 6543,
        balconySqFt: 0,
        vastuScore: 100,
        facing: 'South Facing 91 Ft Frontage',
        description:
          'Prime retail showroom facing the 60 ft Manish Nagar main road with dedicated 2,010 sq ft parking share and undivided 1,253 sq ft land ownership.',
        rooms: [
          {
            id: 'room-vi-ground',
            name: 'Ground Floor Retail Showroom',
            dimensions: `60'0" × 50'0"`,
            sqft: 2991,
            sqm: 277.8,
            vastuQuadrant: 'South-East (Agni / Commercial)',
            finishes: 'Double-height clear structural glass frontage with heavy-duty vitrified retail flooring',
            lighting: 'High-lumen track lights and accent chandeliers',
            coordinates: { x: 50, y: 50, width: 250, height: 180 },
          },
          {
            id: 'room-vi-first',
            name: 'First Floor Showroom Mezzanine',
            dimensions: `70'0" × 50'0"`,
            sqft: 3552,
            sqm: 330,
            vastuQuadrant: 'East (Surya Mandalam)',
            finishes: 'Reinforced RCC flooring with glass balustrades overlooking the atrium',
            lighting: 'Concealed LED architectural lighting',
            coordinates: { x: 60, y: 60, width: 260, height: 190 },
          },
        ],
      },
    ],
  },
];

export interface NeighborhoodLandmark {
  id: string;
  name: string;
  category: 'Transit' | 'Business' | 'Healthcare' | 'Education' | 'Leisure';
  distanceKm: string;
  driveTimeMin: string;
  description: string;
}

export const NEIGHBORHOOD_LANDMARKS: NeighborhoodLandmark[] = [
  {
    id: 'l1',
    name: 'Dr. Babasaheb Ambedkar International Airport',
    category: 'Transit',
    distanceKm: '3.8 km',
    driveTimeMin: '8 mins',
    description: 'Fast direct drive via Wardha Road corridor with domestic & international connectivity.',
  },
  {
    id: 'l2',
    name: 'Airport South / Manish Nagar Metro Station',
    category: 'Transit',
    distanceKm: '1.2 km',
    driveTimeMin: '3 mins',
    description: 'Rapid seamless metro transit connecting North and South Nagpur corridors.',
  },
  {
    id: 'l3',
    name: 'MIHAN SEZ & AIIMS Medical Campus',
    category: 'Healthcare',
    distanceKm: '6.5 km',
    driveTimeMin: '12 mins',
    description: 'Premier medical university and multi-specialty tertiary care hospital.',
  },
  {
    id: 'l4',
    name: 'Infosys, TCS & Tech Mahindra Campus',
    category: 'Business',
    distanceKm: '7.2 km',
    driveTimeMin: '14 mins',
    description: 'Nagpur’s flagship technology corridor employing over 35,000 IT professionals.',
  },
  {
    id: 'l5',
    name: 'Delhi Public School (DPS) & Somalwada Schools',
    category: 'Education',
    distanceKm: '2.1 km',
    driveTimeMin: '5 mins',
    description: 'Top-tier ICSE and CBSE educational institutions within neighborhood radius.',
  },
  {
    id: 'l6',
    name: 'Empress Mall & Prozone Galleria',
    category: 'Leisure',
    distanceKm: '7.8 km',
    driveTimeMin: '15 mins',
    description: 'Premium shopping, multiplex cinemas, fine dining, and entertainment.',
  },
];

export interface CompanyPillar {
  number: string;
  title: string;
  description: string;
  metric: string;
  metricLabel: string;
}

export const COMPANY_PILLARS: CompanyPillar[] = [
  {
    number: '01',
    title: 'Architectural Integrity & Vastu Science',
    description:
      'Every VEDMAY development harmonizes ancient Indian Vastu Shastra principles with modern civil engineering, optimizing natural light, cosmic energy flow, and thermal comfort.',
    metric: '100%',
    metricLabel: 'Vastu Compliant Layouts',
  },
  {
    number: '02',
    title: 'Precision Structural Engineering',
    description:
      'We build with Fe-550D grade steel, earthquake-resilient RCC framework, and waterproofing systems exceeding standard industry codes by 40%.',
    metric: '1.8M+',
    metricLabel: 'Sq. Ft. Built & Delivered',
  },
  {
    number: '03',
    title: 'Transparent Governance & Title Clearance',
    description:
      'Over a decade of zero-litigation records, transparent escrow accounts, sanctioned plans from NMRDA/NMC, and verified RERA approvals for complete peace of mind.',
    metric: '12+',
    metricLabel: 'Years of Trust in Nagpur',
  },
  {
    number: '04',
    title: 'Sustainable Green Innovations',
    description:
      'Leading Nagpur real estate with rooftop solar arrays, dedicated dual-port EV chargers for modern mobility, and multi-stage rainwater harvesting pits.',
    metric: '1,200+',
    metricLabel: 'Delighted Homeowners',
  },
];
