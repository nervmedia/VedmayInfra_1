import React, { useState } from 'react';
import { Calculator, CheckCircle2, TrendingUp, IndianRupee, ArrowRight, ShieldCheck } from 'lucide-react';
import { calculateMortgageEMI, formatCurrencyINR } from '../utils/calculator';

interface MortgageCalculatorProps {
  onOpenBooking: () => void;
}

export const MortgageCalculator: React.FC<MortgageCalculatorProps> = ({ onOpenBooking }) => {
  const [propertyPrice, setPropertyPrice] = useState<number>(14500000); // 1.45 Cr for Vedira Fortune
  const [downPaymentPercent, setDownPaymentPercent] = useState<number>(20);
  const [tenureYears, setTenureYears] = useState<number>(20);
  const [interestRate, setInterestRate] = useState<number>(8.5);

  const emiData = calculateMortgageEMI(
    propertyPrice,
    downPaymentPercent,
    interestRate,
    tenureYears
  );

  const downPaymentAmount = (propertyPrice * downPaymentPercent) / 100;
  const principalPercent = emiData.totalPayable > 0
    ? Math.round((emiData.principalAmount / emiData.totalPayable) * 100)
    : 100;
  const interestPercent = 100 - principalPercent;

  return (
    <section id="calculator" className="py-24 bg-[#080C14] text-neutral-100 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="max-w-3xl mb-14">
          <div className="text-xs uppercase tracking-[0.25em] text-amber-400 font-medium mb-3">
            Financial Advisory & Investment
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-serif font-normal tracking-tight text-white mb-4">
            Mortgage & Investment Planner
          </h2>
          <p className="text-neutral-400 text-sm sm:text-base font-light leading-relaxed">
            Estimate your monthly outlays and evaluate capital asset allocation with competitive
            housing loan terms backed by leading nationalized and private banking partners.
          </p>
        </div>

        {/* Calculator Interactive Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Sliders Input Panel (7 Cols) */}
          <div className="lg:col-span-7 bg-neutral-900 border border-neutral-800 rounded-sm p-6 sm:p-8 space-y-6">
            {/* Property Price Slider */}
            <div>
              <div className="flex justify-between items-center mb-2">
                <label className="text-xs font-medium uppercase tracking-wider text-neutral-300">
                  Property Value
                </label>
                <span className="text-sm sm:text-base font-semibold font-mono text-amber-400 tabular-nums">
                  {formatCurrencyINR(propertyPrice)}
                </span>
              </div>
              <input
                type="range"
                min="4500000"
                max="35000000"
                step="500000"
                value={propertyPrice}
                onChange={(e) => setPropertyPrice(Number(e.target.value))}
                className="w-full h-1.5 bg-neutral-800 rounded-lg appearance-none cursor-pointer accent-amber-400"
              />
              <div className="flex justify-between text-[10px] text-neutral-500 font-mono mt-1">
                <span>₹45 Lakh (Gurukul)</span>
                <span>₹1.45 Cr (Vedira Fortune)</span>
                <span>₹3.5 Cr (Sky Penthouse)</span>
              </div>
            </div>

            {/* Down Payment Slider */}
            <div>
              <div className="flex justify-between items-center mb-2">
                <label className="text-xs font-medium uppercase tracking-wider text-neutral-300">
                  Down Payment ({downPaymentPercent}%)
                </label>
                <span className="text-sm sm:text-base font-semibold font-mono text-white tabular-nums">
                  {formatCurrencyINR(downPaymentAmount)}
                </span>
              </div>
              <input
                type="range"
                min="10"
                max="50"
                step="5"
                value={downPaymentPercent}
                onChange={(e) => setDownPaymentPercent(Number(e.target.value))}
                className="w-full h-1.5 bg-neutral-800 rounded-lg appearance-none cursor-pointer accent-amber-400"
              />
              <div className="flex justify-between text-[10px] text-neutral-500 font-mono mt-1">
                <span>10% Minimum</span>
                <span>20% Standard</span>
                <span>50% Custom</span>
              </div>
            </div>

            {/* Loan Tenure Slider */}
            <div>
              <div className="flex justify-between items-center mb-2">
                <label className="text-xs font-medium uppercase tracking-wider text-neutral-300">
                  Loan Tenure
                </label>
                <span className="text-sm sm:text-base font-semibold font-mono text-white tabular-nums">
                  {tenureYears} Years ({tenureYears * 12} Months)
                </span>
              </div>
              <input
                type="range"
                min="5"
                max="30"
                step="5"
                value={tenureYears}
                onChange={(e) => setTenureYears(Number(e.target.value))}
                className="w-full h-1.5 bg-neutral-800 rounded-lg appearance-none cursor-pointer accent-amber-400"
              />
              <div className="flex justify-between text-[10px] text-neutral-500 font-mono mt-1">
                <span>5 Years</span>
                <span>15 Years</span>
                <span>30 Years</span>
              </div>
            </div>

            {/* Interest Rate Slider */}
            <div>
              <div className="flex justify-between items-center mb-2">
                <label className="text-xs font-medium uppercase tracking-wider text-neutral-300">
                  Annual Interest Rate
                </label>
                <span className="text-sm sm:text-base font-semibold font-mono text-amber-400 tabular-nums">
                  {interestRate}% p.a.
                </span>
              </div>
              <input
                type="range"
                min="7.5"
                max="12.0"
                step="0.1"
                value={interestRate}
                onChange={(e) => setInterestRate(Number(e.target.value))}
                className="w-full h-1.5 bg-neutral-800 rounded-lg appearance-none cursor-pointer accent-amber-400"
              />
              <div className="flex justify-between text-[10px] text-neutral-500 font-mono mt-1">
                <span>7.5% (Prime Tier)</span>
                <span>8.5% (Current Market)</span>
                <span>12.0%</span>
              </div>
            </div>

            {/* Pre-Approved Banking Partners Trust Note */}
            <div className="pt-4 border-t border-neutral-800 text-xs text-neutral-400 flex items-center gap-3">
              <ShieldCheck className="w-5 h-5 text-emerald-400 shrink-0" />
              <span>
                Pre-approved project files with SBI, HDFC Bank, ICICI Bank, Axis Bank, and Bank of
                Baroda for rapid 48-hour sanctions.
              </span>
            </div>
          </div>

          {/* EMI Result & Amortization Breakdown (5 Cols) */}
          <div className="lg:col-span-5 bg-neutral-900 border border-neutral-800 rounded-sm p-6 sm:p-8 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between pb-3 mb-6 border-b border-neutral-800">
                <span className="text-xs font-medium uppercase tracking-wider text-neutral-400">
                  Estimated Monthly Outlay
                </span>
                <span className="text-[11px] font-mono text-emerald-400 bg-emerald-950/60 border border-emerald-800/80 px-2 py-0.5 rounded">
                  Instant Estimate
                </span>
              </div>

              {/* Monthly EMI Large Number */}
              <div className="mb-8">
                <div className="text-3xl sm:text-4xl lg:text-5xl font-serif font-bold text-amber-400 tabular-nums tracking-tight">
                  ₹{emiData.monthlyEMI.toLocaleString('en-IN')}
                </div>
                <span className="text-xs text-neutral-400 uppercase tracking-widest font-mono mt-1 block">
                  Per Month / EMI
                </span>
              </div>

              {/* Repayment Ratio Bar */}
              <div className="mb-6">
                <div className="flex justify-between text-xs text-neutral-400 mb-2 font-mono">
                  <span className="flex items-center gap-1.5">
                    <span className="w-2.5 h-2.5 rounded-full bg-amber-400 inline-block" />
                    <span>Principal ({principalPercent}%)</span>
                  </span>
                  <span className="flex items-center gap-1.5">
                    <span className="w-2.5 h-2.5 rounded-full bg-neutral-600 inline-block" />
                    <span>Interest ({interestPercent}%)</span>
                  </span>
                </div>
                <div className="w-full h-3 bg-neutral-800 rounded-full overflow-hidden flex">
                  <div
                    className="h-full bg-amber-400 transition-all duration-300"
                    style={{ width: `${principalPercent}%` }}
                  />
                  <div
                    className="h-full bg-neutral-600 transition-all duration-300"
                    style={{ width: `${interestPercent}%` }}
                  />
                </div>
              </div>

              {/* Detailed Numbers Breakdown */}
              <div className="space-y-3 border-t border-neutral-800 pt-4 text-xs font-mono">
                <div className="flex justify-between text-neutral-400">
                  <span>Loan Principal:</span>
                  <span className="text-white font-medium">
                    {formatCurrencyINR(emiData.principalAmount)}
                  </span>
                </div>
                <div className="flex justify-between text-neutral-400">
                  <span>Total Interest Payable:</span>
                  <span className="text-white font-medium">
                    {formatCurrencyINR(emiData.totalInterest)}
                  </span>
                </div>
                <div className="flex justify-between text-neutral-400">
                  <span>Total Repayment:</span>
                  <span className="text-amber-300 font-semibold">
                    {formatCurrencyINR(emiData.totalPayable)}
                  </span>
                </div>
              </div>
            </div>

            <div className="mt-8 pt-6 border-t border-neutral-800">
              <button
                onClick={onOpenBooking}
                className="w-full py-3 bg-amber-400 hover:bg-amber-300 text-neutral-950 font-semibold text-xs uppercase tracking-wider rounded-sm transition-colors flex items-center justify-center gap-2 cursor-pointer"
              >
                <span>Request Financial Consultation</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
