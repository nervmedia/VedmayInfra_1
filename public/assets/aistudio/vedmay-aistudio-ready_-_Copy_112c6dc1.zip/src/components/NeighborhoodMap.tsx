import React, { useState } from 'react';
import {
  MapPin,
  Clock,
  Compass,
  Navigation,
  Train,
  Plane,
  Briefcase,
  GraduationCap,
  Building,
  HeartPulse,
} from 'lucide-react';
import { NEIGHBORHOOD_LANDMARKS, NeighborhoodLandmark } from '../data/properties';

export const NeighborhoodMap: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedLandmarkId, setSelectedLandmarkId] = useState<string>(
    NEIGHBORHOOD_LANDMARKS[0].id
  );

  const filteredLandmarks =
    selectedCategory === 'all'
      ? NEIGHBORHOOD_LANDMARKS
      : NEIGHBORHOOD_LANDMARKS.filter((l) => l.category === selectedCategory);

  const activeLandmark =
    NEIGHBORHOOD_LANDMARKS.find((l) => l.id === selectedLandmarkId) || NEIGHBORHOOD_LANDMARKS[0];

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'Transit':
        return Plane;
      case 'Business':
        return Briefcase;
      case 'Healthcare':
        return HeartPulse;
      case 'Education':
        return GraduationCap;
      case 'Leisure':
        return Building;
      default:
        return MapPin;
    }
  };

  return (
    <section id="neighborhood" className="py-24 bg-[#070A0F] text-neutral-100 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 pb-6 border-b border-neutral-800">
          <div>
            <div className="text-xs uppercase tracking-[0.25em] text-amber-400 font-medium mb-3">
              Strategic Nagpur Connectivity
            </div>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-serif font-normal tracking-tight text-white">
              The Epicenter of Everything
            </h2>
          </div>
          <p className="text-neutral-400 text-xs sm:text-sm font-light max-w-md mt-4 md:mt-0">
            Situated in New Manish Nagar and the rapid-growth Wardha Road arterial belt, VEDMAY
            residences place you moments away from international transit, IT parks, and top-tier
            institutions.
          </p>
        </div>

        {/* Category Filter Tabs */}
        <div className="flex flex-wrap items-center gap-1.5 p-1 bg-neutral-900/80 border border-neutral-800 rounded-sm mb-8 max-w-fit">
          <button
            onClick={() => setSelectedCategory('all')}
            className={`px-3.5 py-1.5 text-xs font-medium rounded-sm transition-colors cursor-pointer ${
              selectedCategory === 'all'
                ? 'bg-amber-400 text-neutral-950 font-semibold shadow-sm'
                : 'text-neutral-400 hover:text-white'
            }`}
          >
            All Destinations
          </button>
          <button
            onClick={() => setSelectedCategory('Transit')}
            className={`px-3.5 py-1.5 text-xs font-medium rounded-sm transition-colors cursor-pointer ${
              selectedCategory === 'Transit'
                ? 'bg-amber-400 text-neutral-950 font-semibold shadow-sm'
                : 'text-neutral-400 hover:text-white'
            }`}
          >
            Airport & Metro
          </button>
          <button
            onClick={() => setSelectedCategory('Business')}
            className={`px-3.5 py-1.5 text-xs font-medium rounded-sm transition-colors cursor-pointer ${
              selectedCategory === 'Business'
                ? 'bg-amber-400 text-neutral-950 font-semibold shadow-sm'
                : 'text-neutral-400 hover:text-white'
            }`}
          >
            IT Corridors
          </button>
          <button
            onClick={() => setSelectedCategory('Healthcare')}
            className={`px-3.5 py-1.5 text-xs font-medium rounded-sm transition-colors cursor-pointer ${
              selectedCategory === 'Healthcare'
                ? 'bg-amber-400 text-neutral-950 font-semibold shadow-sm'
                : 'text-neutral-400 hover:text-white'
            }`}
          >
            AIIMS & Healthcare
          </button>
          <button
            onClick={() => setSelectedCategory('Education')}
            className={`px-3.5 py-1.5 text-xs font-medium rounded-sm transition-colors cursor-pointer ${
              selectedCategory === 'Education'
                ? 'bg-amber-400 text-neutral-950 font-semibold shadow-sm'
                : 'text-neutral-400 hover:text-white'
            }`}
          >
            Top Schools
          </button>
        </div>

        {/* Interactive Layout: Radar Map Canvas (7 Cols) + Landmark Destination Feed (5 Cols) */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Interactive Radar Vector Map */}
          <div className="lg:col-span-7 bg-neutral-900 border border-neutral-800 rounded-sm p-4 sm:p-6 relative overflow-hidden">
            <div className="flex items-center justify-between pb-3 mb-3 border-b border-neutral-800 text-xs">
              <span className="text-amber-400 font-mono flex items-center gap-1.5">
                <Compass className="w-4 h-4" />
                <span>Geographic Transit Map · Wardha Road Axis</span>
              </span>
              <span className="text-neutral-400 font-mono text-[11px]">
                Vedira Fortune (Center Point)
              </span>
            </div>

            {/* Stylized Vector Radar Map */}
            <div className="relative aspect-[4/3] w-full bg-[#05070B] rounded border border-neutral-800/80 overflow-hidden flex items-center justify-center">
              <svg viewBox="0 0 500 400" className="w-full h-full select-none">
                {/* Radial Range Rings */}
                <circle cx="250" cy="200" r="60" fill="none" stroke="#1e293b" strokeWidth="1" strokeDasharray="3 3" />
                <circle cx="250" cy="200" r="120" fill="none" stroke="#1e293b" strokeWidth="1" strokeDasharray="3 3" />
                <circle cx="250" cy="200" r="180" fill="none" stroke="#1e293b" strokeWidth="1" strokeDasharray="3 3" />

                {/* Distance markers */}
                <text x="250" y="136" fill="#64748b" fontSize="8" textAnchor="middle">2 KM RADIUS (5 MINS)</text>
                <text x="250" y="76" fill="#64748b" fontSize="8" textAnchor="middle">5 KM RADIUS (10 MINS)</text>
                <text x="250" y="16" fill="#64748b" fontSize="8" textAnchor="middle">8 KM RADIUS (15 MINS)</text>

                {/* Wardha Road Highway Axis */}
                <path d="M50,380 L250,200 L450,20" stroke="#334155" strokeWidth="3" />
                <path d="M50,380 L250,200 L450,20" stroke="#D4AF37" strokeWidth="1" strokeOpacity="0.4" strokeDasharray="6 4" />
                <text x="390" y="60" fill="#94a3b8" fontSize="8" transform="rotate(-40 390,60)">WARDHA ROAD ARTERIAL</text>

                {/* Ring Road Connector */}
                <path d="M40,230 Q250,150 460,260" stroke="#1e293b" strokeWidth="2" fill="none" />
                <text x="140" y="170" fill="#64748b" fontSize="8">OUTER RING ROAD</text>

                {/* Center Hub: Vedira Fortune */}
                <g transform="translate(250, 200)">
                  <circle cx="0" cy="0" r="18" fill="#D4AF37" fillOpacity="0.15" className="animate-ping" />
                  <circle cx="0" cy="0" r="10" fill="#D4AF37" />
                  <circle cx="0" cy="0" r="4" fill="#070A0F" />
                  <text x="0" y="-14" fill="#FEF08A" fontSize="10" fontWeight="bold" textAnchor="middle">
                    VEDIRA FORTUNE
                  </text>
                  <text x="0" y="24" fill="#C5A880" fontSize="8" textAnchor="middle">
                    Somalwada / Manish Nagar
                  </text>
                </g>

                {/* Interactive Landmark Pins */}
                {/* L1: Airport (NW, 3.8 km) */}
                <g
                  transform="translate(160, 130)"
                  className="cursor-pointer"
                  onClick={() => setSelectedLandmarkId('l1')}
                >
                  <circle
                    cx="0"
                    cy="0"
                    r={selectedLandmarkId === 'l1' ? '9' : '6'}
                    fill={selectedLandmarkId === 'l1' ? '#38bdf8' : '#0284c7'}
                  />
                  <text x="0" y="18" fill="#f8fafc" fontSize="9" textAnchor="middle">
                    Nagpur Airport (8 min)
                  </text>
                </g>

                {/* L2: Metro (1.2 km) */}
                <g
                  transform="translate(290, 170)"
                  className="cursor-pointer"
                  onClick={() => setSelectedLandmarkId('l2')}
                >
                  <circle
                    cx="0"
                    cy="0"
                    r={selectedLandmarkId === 'l2' ? '9' : '6'}
                    fill={selectedLandmarkId === 'l2' ? '#38bdf8' : '#0284c7'}
                  />
                  <text x="0" y="18" fill="#f8fafc" fontSize="9" textAnchor="middle">
                    Metro Station (3 min)
                  </text>
                </g>

                {/* L3: AIIMS / MIHAN (6.5 km) */}
                <g
                  transform="translate(100, 310)"
                  className="cursor-pointer"
                  onClick={() => setSelectedLandmarkId('l3')}
                >
                  <circle
                    cx="0"
                    cy="0"
                    r={selectedLandmarkId === 'l3' ? '9' : '6'}
                    fill={selectedLandmarkId === 'l3' ? '#ef4444' : '#dc2626'}
                  />
                  <text x="0" y="18" fill="#f8fafc" fontSize="9" textAnchor="middle">
                    AIIMS Hospital (12 min)
                  </text>
                </g>

                {/* L4: IT Hub (7.2 km) */}
                <g
                  transform="translate(80, 270)"
                  className="cursor-pointer"
                  onClick={() => setSelectedLandmarkId('l4')}
                >
                  <circle
                    cx="0"
                    cy="0"
                    r={selectedLandmarkId === 'l4' ? '9' : '6'}
                    fill={selectedLandmarkId === 'l4' ? '#38bdf8' : '#0284c7'}
                  />
                  <text x="0" y="18" fill="#f8fafc" fontSize="9" textAnchor="middle">
                    TCS & Infosys (14 min)
                  </text>
                </g>

                {/* L5: DPS School (2.1 km) */}
                <g
                  transform="translate(320, 240)"
                  className="cursor-pointer"
                  onClick={() => setSelectedLandmarkId('l5')}
                >
                  <circle
                    cx="0"
                    cy="0"
                    r={selectedLandmarkId === 'l5' ? '9' : '6'}
                    fill={selectedLandmarkId === 'l5' ? '#22c55e' : '#16a34a'}
                  />
                  <text x="0" y="18" fill="#f8fafc" fontSize="9" textAnchor="middle">
                    DPS School (5 min)
                  </text>
                </g>

                {/* L6: Empress Mall (7.8 km) */}
                <g
                  transform="translate(380, 80)"
                  className="cursor-pointer"
                  onClick={() => setSelectedLandmarkId('l6')}
                >
                  <circle
                    cx="0"
                    cy="0"
                    r={selectedLandmarkId === 'l6' ? '9' : '6'}
                    fill={selectedLandmarkId === 'l6' ? '#a855f7' : '#9333ea'}
                  />
                  <text x="0" y="18" fill="#f8fafc" fontSize="9" textAnchor="middle">
                    Empress Mall (15 min)
                  </text>
                </g>
              </svg>
            </div>
          </div>

          {/* Landmark Cards Feed (5 Cols) */}
          <div className="lg:col-span-5 space-y-3">
            {filteredLandmarks.map((landmark) => {
              const Icon = getCategoryIcon(landmark.category);
              const isSelected = selectedLandmarkId === landmark.id;

              return (
                <div
                  key={landmark.id}
                  onClick={() => setSelectedLandmarkId(landmark.id)}
                  className={`p-4 rounded-sm border cursor-pointer transition-all duration-200 flex items-start justify-between gap-4 ${
                    isSelected
                      ? 'bg-neutral-900 border-amber-400 shadow-md'
                      : 'bg-neutral-950/80 border-neutral-800 hover:border-neutral-700 hover:bg-neutral-900/40'
                  }`}
                >
                  <div className="flex items-start gap-3">
                    <div
                      className={`p-2 rounded-sm shrink-0 mt-0.5 ${
                        isSelected
                          ? 'bg-amber-400 text-neutral-950'
                          : 'bg-neutral-900 text-neutral-400'
                      }`}
                    >
                      <Icon className="w-4 h-4" />
                    </div>
                    <div>
                      <h4
                        className={`text-sm font-medium transition-colors ${
                          isSelected ? 'text-white' : 'text-neutral-300'
                        }`}
                      >
                        {landmark.name}
                      </h4>
                      <p className="text-xs text-neutral-400 mt-1">{landmark.description}</p>
                    </div>
                  </div>

                  <div className="text-right shrink-0">
                    <div className="text-xs font-mono font-semibold text-amber-300 flex items-center justify-end gap-1">
                      <Clock className="w-3 h-3 text-amber-400" />
                      <span>{landmark.driveTimeMin}</span>
                    </div>
                    <span className="text-[11px] text-neutral-500 font-mono mt-0.5 block">
                      {landmark.distanceKm}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
};
