import React, { useState, useMemo } from 'react';
import { Search, X, MapPin, Building, ArrowRight, Sparkles } from 'lucide-react';
import { PROPERTIES, Property } from '../data/properties';
import { PageType, OurProjectsStatusFilter } from './Navbar';

interface SearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigate: (page: PageType, subTab?: OurProjectsStatusFilter) => void;
  onOpenBooking: (projectName: string) => void;
}

export const SearchModal: React.FC<SearchModalProps> = ({
  isOpen,
  onClose,
  onNavigate,
  onOpenBooking,
}) => {
  const [query, setQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  const searchResults = useMemo(() => {
    if (!query.trim() && selectedCategory === 'all') {
      return PROPERTIES.slice(0, 4);
    }

    const q = query.toLowerCase().trim();
    return PROPERTIES.filter((p) => {
      if (selectedCategory !== 'all') {
        if (selectedCategory === 'commercial' && p.category !== 'commercial') return false;
        if (selectedCategory !== 'commercial' && !p.tabCategories.includes(selectedCategory as any)) return false;
      }

      if (!q) return true;

      const titleMatch = p.title.toLowerCase().includes(q);
      const locMatch = p.location.toLowerCase().includes(q);
      const descMatch = p.description.toLowerCase().includes(q);
      const statusMatch = p.status.toLowerCase().includes(q);
      const specsMatch = p.highlightSpecs.some((s) => s.toLowerCase().includes(q));

      return titleMatch || locMatch || descMatch || statusMatch || specsMatch;
    });
  }, [query, selectedCategory]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-16 sm:pt-24 px-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="bg-[#0B0F17] border border-neutral-800 rounded-sm w-full max-w-3xl overflow-hidden shadow-2xl">
        {/* Search Input Bar */}
        <div className="p-4 sm:p-6 border-b border-neutral-800 flex items-center gap-3">
          <Search className="w-5 h-5 text-amber-400 shrink-0" />
          <input
            type="text"
            autoFocus
            placeholder="Search developments, 2 BHK, 3 BHK, Somalwada, Manish Nagar, MIHAN..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="w-full bg-transparent text-white placeholder-neutral-500 text-sm sm:text-base focus:outline-none"
          />
          {query && (
            <button
              onClick={() => setQuery('')}
              className="text-xs text-neutral-400 hover:text-white px-2 py-1"
            >
              Clear
            </button>
          )}
          <button
            onClick={onClose}
            className="p-1.5 text-neutral-400 hover:text-white rounded-sm transition-colors"
            aria-label="Close Search"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Quick Filter Tags */}
        <div className="px-4 sm:px-6 py-3 bg-neutral-950/80 border-b border-neutral-800/80 flex flex-wrap items-center gap-2 text-xs">
          <span className="text-neutral-500 uppercase font-mono tracking-wider text-[11px] mr-1">
            Filter:
          </span>
          <button
            onClick={() => setSelectedCategory('all')}
            className={`px-3 py-1 rounded-xs transition-colors cursor-pointer ${
              selectedCategory === 'all'
                ? 'bg-amber-400 text-neutral-950 font-semibold'
                : 'bg-neutral-900 text-neutral-300 hover:text-white'
            }`}
          >
            All
          </button>
          <button
            onClick={() => setSelectedCategory('new-launches')}
            className={`px-3 py-1 rounded-xs transition-colors cursor-pointer ${
              selectedCategory === 'new-launches'
                ? 'bg-amber-400 text-neutral-950 font-semibold'
                : 'bg-neutral-900 text-neutral-300 hover:text-white'
            }`}
          >
            New Launches
          </button>
          <button
            onClick={() => setSelectedCategory('ready-to-move')}
            className={`px-3 py-1 rounded-xs transition-colors cursor-pointer ${
              selectedCategory === 'ready-to-move'
                ? 'bg-amber-400 text-neutral-950 font-semibold'
                : 'bg-neutral-900 text-neutral-300 hover:text-white'
            }`}
          >
            Ready to Move
          </button>
          <button
            onClick={() => setSelectedCategory('communities')}
            className={`px-3 py-1 rounded-xs transition-colors cursor-pointer ${
              selectedCategory === 'communities'
                ? 'bg-amber-400 text-neutral-950 font-semibold'
                : 'bg-neutral-900 text-neutral-300 hover:text-white'
            }`}
          >
            Townships
          </button>
          <button
            onClick={() => setSelectedCategory('commercial')}
            className={`px-3 py-1 rounded-xs transition-colors cursor-pointer ${
              selectedCategory === 'commercial'
                ? 'bg-amber-400 text-neutral-950 font-semibold'
                : 'bg-neutral-900 text-neutral-300 hover:text-white'
            }`}
          >
            Commercial
          </button>
        </div>

        {/* Results List */}
        <div className="max-h-[60vh] overflow-y-auto divide-y divide-neutral-800/80 p-2 sm:p-4 space-y-1">
          {searchResults.length === 0 ? (
            <div className="py-12 text-center text-neutral-400 text-xs">
              No developments found matching "{query}". Try searching for Somalwada, 3 BHK, or Manish Nagar.
            </div>
          ) : (
            searchResults.map((property) => (
              <div
                key={property.id}
                className="p-3 sm:p-4 rounded-sm hover:bg-neutral-900/80 transition-colors flex flex-col sm:flex-row sm:items-center justify-between gap-4 group"
              >
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-[10px] font-mono uppercase tracking-wider text-amber-400 px-1.5 py-0.5 bg-amber-400/10 border border-amber-400/30 rounded-xs">
                      {property.status}
                    </span>
                    <span className="text-xs text-neutral-400 flex items-center gap-1">
                      <MapPin className="w-3 h-3 text-neutral-500" />
                      {property.location}
                    </span>
                  </div>
                  <h4 className="text-base font-serif text-white group-hover:text-amber-300 transition-colors">
                    {property.title}
                  </h4>
                  <p className="text-xs text-neutral-400 font-light mt-0.5 line-clamp-1">
                    {property.subtitle} · {property.carpetAreaRange}
                  </p>
                </div>

                <div className="flex items-center gap-3 shrink-0">
                  <div className="text-right">
                    <div className="text-xs font-serif font-semibold text-amber-400 tabular-nums">
                      {property.priceDisplay}
                    </div>
                  </div>

                  <button
                    onClick={() => {
                      onClose();
                      onNavigate('all-projects');
                    }}
                    className="px-3 py-1.5 bg-neutral-800 hover:bg-neutral-700 text-white text-[11px] uppercase tracking-wider rounded-xs transition-colors flex items-center gap-1 cursor-pointer"
                  >
                    <span>View</span>
                    <ArrowRight className="w-3 h-3 text-amber-400" />
                  </button>

                  <button
                    onClick={() => {
                      onClose();
                      onOpenBooking(property.title);
                    }}
                    className="px-3 py-1.5 bg-amber-400 hover:bg-amber-300 text-neutral-950 text-[11px] font-semibold uppercase tracking-wider rounded-xs transition-colors cursor-pointer"
                  >
                    Book
                  </button>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Modal Footer */}
        <div className="p-3 bg-neutral-950 border-t border-neutral-800 text-xs text-neutral-400 flex items-center justify-between">
          <span className="font-mono text-[11px]">
            Showing {searchResults.length} {searchResults.length === 1 ? 'development' : 'developments'}
          </span>
          <button
            onClick={() => {
              onClose();
              onNavigate('all-projects');
            }}
            className="text-amber-400 hover:text-amber-300 font-medium text-[11px] uppercase tracking-wider transition-colors cursor-pointer"
          >
            Explore Full Catalog →
          </button>
        </div>
      </div>
    </div>
  );
};
