import React, { useState } from 'react';
import {
  Sun,
  KeyRound,
  Zap,
  Coffee,
  Sparkles,
  Droplets,
  ShieldAlert,
  ArrowUpRight,
  Wind,
} from 'lucide-react';
import { ArchitecturalImage } from './ArchitecturalImage';

interface AmenitiesDeckProps {
  onOpenBooking: () => void;
}

export const AmenitiesDeck: React.FC<AmenitiesDeckProps> = ({ onOpenBooking }) => {
  const [activeAmenityIndex, setActiveAmenityIndex] = useState(0);

  const amenities = [
    {
      id: 'solar',
      icon: Sun,
      title: '5kW Common Solar Grid',
      category: 'Sustainable Energy',
      highlight: 'Zero Common Area Carbon Footprint',
      description:
        'Vedira Fortune integrates a high-efficiency rooftop photovoltaic array powering common elevators, stairwell lighting, and water pumping systems, dramatically slashing monthly maintenance costs.',
      spec: '5kW Monocrystalline Grid-Tied PV Array',
    },
    {
      id: 'biometric',
      icon: KeyRound,
      title: 'Biometric Thumb-Print Security',
      category: 'Smart Living',
      highlight: 'Keyless Multi-Factor Entry',
      description:
        'State-of-the-art optical biometric digital door locks installed on every apartment main door, featuring encrypted PIN pads, RFID card access, mechanical emergency keys, and intruder alarm sensors.',
      spec: 'Grade-A Smart Locks with 0.3s Recognition',
    },
    {
      id: 'ev',
      icon: Zap,
      title: 'EV Fast-Charging Bays',
      category: 'Clean Mobility',
      highlight: 'Future-Ready Electric Vehicle Infrastructure',
      description:
        'Dedicated Level-2 high-speed EV charging stations in basement and stilt parking bays, engineered to support all modern luxury electric 4-wheelers and 2-wheelers.',
      spec: '3-Phase 22kW Fast AC Charging Points',
    },
    {
      id: 'gazebo',
      icon: Coffee,
      title: 'Rooftop Gazebo & Sky Lounge',
      category: 'Exclusive Leisure',
      highlight: 'Private High-Rise Social Pavillion',
      description:
        'An open-air wooden pergola gazebo with ambient pendant lanterns, cushioned lounge banquettes, and panoramic horizon vistas overlooking New Manish Nagar and the city skyline.',
      spec: 'Hardwood Pergola with Weatherproof Seating',
    },
    {
      id: 'yoga',
      icon: Sparkles,
      title: 'Sunrise Yoga & Meditation Deck',
      category: 'Holistic Wellness',
      highlight: 'Ishanya (North-East) Aligned Serenity',
      description:
        'A dedicated acoustic-buffered terrace deck surrounded by lush subtropical aromatic planters, designed specifically for morning pranayama, meditation, and quiet evening reflection.',
      spec: 'Anti-Skid Timber Deck with Planter Buffer',
    },
    {
      id: 'water',
      icon: Droplets,
      title: 'Rainwater Harvesting Systems',
      category: 'Conservation',
      highlight: 'Percolation Pits & Filtration',
      description:
        'High-capacity dual-pit groundwater recharging system capturing 100% of terrace and podium surface run-off, preserving Nagpur’s municipal water balance.',
      spec: 'Multi-Chamber Filter & Desilting Chambers',
    },
  ];

  const currentAmenity = amenities[activeAmenityIndex];

  return (
    <section id="amenities" className="py-24 bg-[#0B0F17] text-neutral-100 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="max-w-3xl mb-14">
          <div className="text-xs uppercase tracking-[0.25em] text-amber-400 font-medium mb-3">
            Holistic Luxury & Eco-Innovation
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-serif font-normal tracking-tight text-white mb-4">
            World-Class Lifestyle Privileges
          </h2>
          <p className="text-neutral-400 text-sm sm:text-base font-light leading-relaxed">
            From smart biometric security to rooftop celestial gardens and sustainable green energy,
            every feature in Vedira Fortune is conceived to elevate your everyday standard of living.
          </p>
        </div>

        {/* Asymmetric Showcase Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          {/* Interactive Feature List (5 Cols) */}
          <div className="lg:col-span-5 space-y-2">
            {amenities.map((item, index) => {
              const Icon = item.icon;
              const isSelected = activeAmenityIndex === index;

              return (
                <div
                  key={item.id}
                  onClick={() => setActiveAmenityIndex(index)}
                  className={`p-4 rounded-sm border cursor-pointer transition-all duration-200 flex items-start gap-4 ${
                    isSelected
                      ? 'bg-neutral-900 border-amber-400/80 shadow-[0_0_20px_rgba(212,175,55,0.15)]'
                      : 'bg-neutral-950/60 border-neutral-800/80 hover:border-neutral-700 hover:bg-neutral-900/40'
                  }`}
                >
                  <div
                    className={`p-2.5 rounded-sm shrink-0 transition-colors ${
                      isSelected
                        ? 'bg-amber-400 text-neutral-950'
                        : 'bg-neutral-900 text-neutral-400'
                    }`}
                  >
                    <Icon className="w-5 h-5" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2">
                      <h4
                        className={`text-sm font-medium transition-colors truncate ${
                          isSelected ? 'text-white' : 'text-neutral-300'
                        }`}
                      >
                        {item.title}
                      </h4>
                      <span className="text-[10px] uppercase font-mono tracking-wider text-amber-400 shrink-0">
                        {item.category}
                      </span>
                    </div>
                    <p className="text-xs text-neutral-400 mt-1 line-clamp-1">{item.highlight}</p>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Marquee Spotlight Showcase Card (7 Cols) */}
          <div className="lg:col-span-7 bg-neutral-900 border border-neutral-800 rounded-sm p-6 sm:p-8 relative overflow-hidden flex flex-col justify-between min-h-[480px]">
            {/* Visual Header */}
            <div>
              <div className="relative aspect-[16/9] w-full rounded overflow-hidden mb-6 border border-neutral-800">
                <ArchitecturalImage
                  id={`amenity-render-${currentAmenity.id}`}
                  category={activeAmenityIndex === 3 ? 'Terrace Deck' : 'Exterior'}
                  title={currentAmenity.title}
                  subtitle={currentAmenity.highlight}
                  aspectRatio="16:9"
                  className="w-full h-full"
                />
              </div>

              <div className="flex items-center gap-2 text-xs uppercase tracking-widest text-amber-400 font-medium mb-2">
                <span>{currentAmenity.category}</span>
                <span aria-hidden="true">·</span>
                <span>Vedira Fortune Exclusive</span>
              </div>

              <h3 className="text-2xl sm:text-3xl font-serif text-white font-medium mb-3">
                {currentAmenity.title}
              </h3>

              <p className="text-neutral-300 text-sm font-light leading-relaxed mb-6">
                {currentAmenity.description}
              </p>
            </div>

            {/* Bottom Specs & Action */}
            <div className="pt-6 border-t border-neutral-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <span className="text-[10px] uppercase tracking-wider text-neutral-500 block mb-0.5">
                  Engineering Specification
                </span>
                <span className="text-xs font-mono text-amber-300 font-medium">
                  {currentAmenity.spec}
                </span>
              </div>
              <button
                onClick={onOpenBooking}
                className="px-5 py-2.5 bg-amber-400 hover:bg-amber-300 text-neutral-950 text-xs font-semibold uppercase tracking-wider rounded-sm transition-colors flex items-center justify-center gap-2 shrink-0 cursor-pointer"
              >
                <span>Experience On-Site</span>
                <ArrowUpRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
