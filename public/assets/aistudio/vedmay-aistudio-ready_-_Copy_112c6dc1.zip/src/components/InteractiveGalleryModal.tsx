import React, { useState } from 'react';
import { X, ChevronLeft, ChevronRight, Maximize2, Calendar, Download } from 'lucide-react';
import { Property } from '../data/properties';
import { ArchitecturalImage } from './ArchitecturalImage';

interface InteractiveGalleryModalProps {
  property: Property | null;
  onClose: () => void;
  onOpenBooking: (projectName: string) => void;
  onOpenBrochure: (projectName: string) => void;
}

export const InteractiveGalleryModal: React.FC<InteractiveGalleryModalProps> = ({
  property,
  onClose,
  onOpenBooking,
  onOpenBrochure,
}) => {
  if (!property) return null;

  const [activeItemIndex, setActiveItemIndex] = useState(0);
  const currentItem = property.gallery[activeItemIndex] || property.gallery[0];

  const handlePrev = () => {
    setActiveItemIndex((prev) => (prev > 0 ? prev - 1 : property.gallery.length - 1));
  };

  const handleNext = () => {
    setActiveItemIndex((prev) => (prev < property.gallery.length - 1 ? prev + 1 : 0));
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 backdrop-blur-md p-4 sm:p-6 overflow-y-auto">
      <div className="relative w-full max-w-5xl bg-neutral-950 border border-neutral-800 rounded-sm shadow-2xl overflow-hidden my-auto">
        {/* Modal Top Bar */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-neutral-800">
          <div>
            <span className="text-[11px] uppercase tracking-widest text-amber-400 font-medium">
              High-Resolution Gallery
            </span>
            <h3 className="text-xl font-serif text-white font-medium">{property.title}</h3>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-neutral-400 hover:text-white transition-colors rounded-sm hover:bg-neutral-900"
            aria-label="Close Gallery"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Main Display Stage */}
        <div className="relative aspect-[16/9] w-full bg-black overflow-hidden flex items-center justify-center">
          <ArchitecturalImage
            id={currentItem.id}
            imageSrc={currentItem.image}
            category={currentItem.category}
            title={currentItem.caption}
            subtitle={`${property.title} · ${property.location}`}
            aspectRatio="16:9"
            className="w-full h-full"
          />

          {/* Nav Controls */}
          {property.gallery.length > 1 && (
            <>
              <button
                onClick={handlePrev}
                className="absolute left-4 top-1/2 -translate-y-1/2 p-2.5 bg-neutral-950/70 hover:bg-neutral-900 text-white rounded-full border border-neutral-700 backdrop-blur-sm transition-all"
                aria-label="Previous Image"
              >
                <ChevronLeft className="w-5 h-5" />
              </button>
              <button
                onClick={handleNext}
                className="absolute right-4 top-1/2 -translate-y-1/2 p-2.5 bg-neutral-950/70 hover:bg-neutral-900 text-white rounded-full border border-neutral-700 backdrop-blur-sm transition-all"
                aria-label="Next Image"
              >
                <ChevronRight className="w-5 h-5" />
              </button>
            </>
          )}

          {/* Frame Index Indicator */}
          <div className="absolute top-4 left-4 bg-neutral-950/80 px-2.5 py-1 rounded text-xs font-mono text-neutral-300 border border-neutral-800">
            {activeItemIndex + 1} / {property.gallery.length}
          </div>
        </div>

        {/* Thumbnail Reel & Footer Actions */}
        <div className="p-6 bg-neutral-900/90 border-t border-neutral-800">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4 mb-4">
            <div>
              <h4 className="text-sm font-medium text-white">{currentItem.caption}</h4>
              <p className="text-xs text-neutral-400 mt-0.5">
                Category: <span className="text-amber-300">{currentItem.category}</span> · Resolution: 4K Ultra-Sharp Architectural Master
              </p>
            </div>
            <div className="flex items-center gap-3 shrink-0">
              <button
                onClick={() => {
                  onClose();
                  onOpenBrochure(property.title);
                }}
                className="px-4 py-2 border border-neutral-700 hover:border-amber-400 text-neutral-300 hover:text-white text-xs font-medium rounded-sm transition-colors flex items-center gap-1.5"
              >
                <Download className="w-3.5 h-3.5 text-amber-400" />
                <span>Brochure</span>
              </button>
              <button
                onClick={() => {
                  onClose();
                  onOpenBooking(property.title);
                }}
                className="px-4 py-2 bg-amber-400 hover:bg-amber-300 text-neutral-950 text-xs font-semibold rounded-sm transition-colors flex items-center gap-1.5"
              >
                <Calendar className="w-3.5 h-3.5" />
                <span>Book Site Walkthrough</span>
              </button>
            </div>
          </div>

          {/* Thumbnails strip */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1">
            {property.gallery.map((item, idx) => (
              <button
                key={item.id}
                onClick={() => setActiveItemIndex(idx)}
                className={`relative shrink-0 w-24 h-16 rounded overflow-hidden border transition-all ${
                  activeItemIndex === idx
                    ? 'border-amber-400 ring-2 ring-amber-400/30'
                    : 'border-neutral-800 opacity-60 hover:opacity-100'
                }`}
              >
                <ArchitecturalImage
                  id={`thumb-${item.id}`}
                  imageSrc={item.image}
                  category={item.category}
                  title=""
                  aspectRatio="16:9"
                  className="w-full h-full"
                />
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
