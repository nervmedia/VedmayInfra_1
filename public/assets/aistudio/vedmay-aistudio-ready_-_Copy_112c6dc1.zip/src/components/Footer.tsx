import React from 'react';
import { MapPin, Phone, Mail, ShieldCheck, ArrowUp } from 'lucide-react';
import { PageType, OurProjectsStatusFilter } from './Navbar';

interface FooterProps {
  onNavigate?: (page: PageType, subTab?: OurProjectsStatusFilter) => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigate }) => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleLinkClick = (e: React.MouseEvent, page: PageType, subTab?: OurProjectsStatusFilter) => {
    e.preventDefault();
    if (onNavigate) {
      onNavigate(page, subTab);
    } else {
      scrollToTop();
    }
  };

  return (
    <footer className="bg-[#05070B] text-neutral-400 border-t border-neutral-800 text-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10 pb-12 border-b border-neutral-900">
          {/* Brand & Corporate Overview (2 cols) */}
          <div className="lg:col-span-2 space-y-4">
            <a
              href="/"
              onClick={(e) => handleLinkClick(e, 'home')}
              className="flex items-center gap-2.5 text-2xl font-serif font-semibold tracking-widest text-white hover:text-amber-400 transition-colors cursor-pointer"
              aria-label="VEDMAY - Return to Home"
            >
              <img
                src="/images/vedmay/logo.png"
                alt="VEDMAY Infra"
                className="h-9 w-auto object-contain rounded-xs shadow-sm"
              />
              <span>VEDMAY</span>
            </a>
            <p className="text-neutral-400 text-xs leading-relaxed max-w-sm font-light">
              Pioneering ultra-luxury residential living and master-planned developments in Nagpur,
              Maharashtra. Harmonizing ancient Vastu architectural wisdom with cutting-edge civil
              engineering and sustainable innovation.
            </p>
            <div className="pt-2 text-neutral-300 space-y-1.5 text-xs font-light">
              <div className="flex items-start gap-2">
                <MapPin className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                <span>
                  Shyam Nagar, Jai Hind Society, Beside Amrut Lawn, Nagpur, Maharashtra, 440034
                </span>
              </div>
              <div className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-amber-400 shrink-0" />
                <a href="tel:+917122894500" className="hover:text-amber-400 transition-colors">
                  +91 712 289 4500 / +91 98230 45678
                </a>
              </div>
              <div className="flex items-center gap-2">
                <Mail className="w-4 h-4 text-amber-400 shrink-0" />
                <a
                  href="mailto:sales@vedmay.com"
                  className="hover:text-amber-400 transition-colors"
                >
                  sales@vedmay.com
                </a>
              </div>
            </div>
          </div>

          {/* Quick Portfolio Links */}
          <div>
            <h4 className="text-white text-xs font-semibold uppercase tracking-wider mb-4 font-mono">
              Developments
            </h4>
            <ul className="space-y-2.5">
              <li>
                <a
                  href="/our-projects"
                  onClick={(e) => handleLinkClick(e, 'our-projects', 'ongoing')}
                  className="hover:text-amber-400 transition-colors cursor-pointer"
                >
                  Vedira Fortune (Ongoing)
                </a>
              </li>
              <li>
                <a
                  href="/our-projects"
                  onClick={(e) => handleLinkClick(e, 'our-projects', 'upcoming')}
                  className="hover:text-amber-400 transition-colors cursor-pointer"
                >
                  Vedira Heights (Upcoming)
                </a>
              </li>
              <li>
                <a
                  href="/our-projects"
                  onClick={(e) => handleLinkClick(e, 'our-projects', 'completed')}
                  className="hover:text-amber-400 transition-colors cursor-pointer"
                >
                  Ramalaya Bliss (Completed)
                </a>
              </li>
              <li>
                <a
                  href="/all-projects"
                  onClick={(e) => handleLinkClick(e, 'all-projects')}
                  className="hover:text-amber-400 transition-colors cursor-pointer"
                >
                  Gurukul Plotted Township
                </a>
              </li>
              <li>
                <a
                  href="/all-projects"
                  onClick={(e) => handleLinkClick(e, 'all-projects')}
                  className="hover:text-amber-400 transition-colors cursor-pointer"
                >
                  Vedmay Avenue One (Commercial)
                </a>
              </li>
            </ul>
          </div>

          {/* Page Directory */}
          <div>
            <h4 className="text-white text-xs font-semibold uppercase tracking-wider mb-4 font-mono">
              Navigation
            </h4>
            <ul className="space-y-2.5">
              <li>
                <a
                  href="/all-projects"
                  onClick={(e) => handleLinkClick(e, 'all-projects')}
                  className="hover:text-amber-400 transition-colors cursor-pointer"
                >
                  All Projects Page
                </a>
              </li>
              <li>
                <a
                  href="/our-projects"
                  onClick={(e) => handleLinkClick(e, 'our-projects', 'all')}
                  className="hover:text-amber-400 transition-colors cursor-pointer"
                >
                  Our Projects Page
                </a>
              </li>
              <li>
                <a
                  href="/about-vedmay"
                  onClick={(e) => handleLinkClick(e, 'about-vedmay')}
                  className="hover:text-amber-400 transition-colors cursor-pointer"
                >
                  About VEDMAY Page
                </a>
              </li>
              <li>
                <a
                  href="/contacts"
                  onClick={(e) => handleLinkClick(e, 'contacts')}
                  className="hover:text-amber-400 transition-colors cursor-pointer"
                >
                  Contacts Page
                </a>
              </li>
            </ul>
          </div>

          {/* Corporate Governance */}
          <div>
            <h4 className="text-white text-xs font-semibold uppercase tracking-wider mb-4 font-mono">
              Governance & Legal
            </h4>
            <ul className="space-y-2.5">
              <li className="flex items-center gap-1.5 text-neutral-300">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                <span>MahaRERA Registered</span>
              </li>
              <li>
                <span className="text-[11px] text-neutral-500 block font-mono">
                  RERA: P50500049281
                </span>
              </li>
              <li>
                <span className="text-[11px] text-neutral-500 block font-mono">
                  Sanction: NMRDA / NMC
                </span>
              </li>
              <li>
                <span className="text-[11px] text-neutral-400 block mt-2">
                  100% Clear Title Verification
                </span>
              </li>
            </ul>
          </div>
        </div>

        {/* Quiet Sub-Footer */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-neutral-500">
          <div>
            © {new Date().getFullYear()} Vedmay Development Private Limited. All rights reserved.
          </div>
          <div className="flex items-center gap-6">
            <span>Privacy Policy</span>
            <span>Terms of Engagement</span>
            <span>RERA Disclosures</span>
            <button
              onClick={scrollToTop}
              className="text-neutral-400 hover:text-amber-400 flex items-center gap-1 transition-colors cursor-pointer"
              title="Scroll to top"
            >
              <span>Back to Top</span>
              <ArrowUp className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
};
