import React, { useState } from 'react';
import {
  MapPin,
  Maximize2,
  Calendar,
  Layers,
  Sparkles,
  Zap,
  Sun,
  Key,
  Flame,
  Compass,
  CheckCircle2,
  Building,
  ArrowRight,
  Filter,
  Clock,
} from 'lucide-react';
import { Property } from '../data/properties';
import { ArchitecturalImage } from './ArchitecturalImage';
import { OurProjectsStatusFilter } from './Navbar';

interface PropertyShowcaseProps {
  properties: Property[];
  onSelectPropertyForFloorPlan: (propertyId: string) => void;
  onOpenGallery: (property: Property) => void;
  onOpenBooking: (projectName: string) => void;
  onOpenBrochure: (projectName: string) => void;
  ourProjectsFilter?: OurProjectsStatusFilter;
  onOurProjectsFilterChange?: (filter: OurProjectsStatusFilter) => void;
}

type CategoryTab = 'all' | 'new-launches' | 'communities' | 'ready-to-move' | 'commercial';

export const PropertyShowcase: React.FC<PropertyShowcaseProps> = ({
  properties,
  onSelectPropertyForFloorPlan,
  onOpenGallery,
  onOpenBooking,
  onOpenBrochure,
  ourProjectsFilter,
  onOurProjectsFilterChange,
}) => {
  // Filter for ALL PROJECTS section
  const [activeCategory, setActiveCategory] = useState<CategoryTab>('all');

  // Filter for OUR PROJECTS section (controlled or uncontrolled fallback)
  const [internalOurProjectsFilter, setInternalOurProjectsFilter] =
    useState<OurProjectsStatusFilter>('all');
  const activeOurProjectsFilter = ourProjectsFilter ?? internalOurProjectsFilter;

  const handleOurProjectsFilterChange = (filter: OurProjectsStatusFilter) => {
    setInternalOurProjectsFilter(filter);
    if (onOurProjectsFilterChange) {
      onOurProjectsFilterChange(filter);
    }
  };

  const newLaunches = properties.filter((p) => p.tabCategories.includes('new-launches'));
  const communities = properties.filter((p) => p.tabCategories.includes('communities'));
  const delivered = properties.filter((p) => p.tabCategories.includes('ready-to-move'));
  const commercial = properties.filter((p) => p.category === 'commercial' || p.tabCategories.includes('commercial'));

  // Filtered properties for ALL PROJECTS
  const allFilteredProperties = activeCategory === 'all'
    ? properties
    : activeCategory === 'new-launches'
    ? newLaunches
    : activeCategory === 'communities'
    ? communities
    : activeCategory === 'ready-to-move'
    ? delivered
    : commercial;

  // Sub-tabs data for OUR PROJECTS (ONGOING, COMPLETED, UPCOMING)
  const ongoingProjects = properties.filter((p) => p.status === 'Under Construction');
  const completedProjects = properties.filter((p) => p.status === 'Ready to Move');
  const upcomingProjects = properties.filter((p) => p.status === 'New Launch');

  // Filtered properties for OUR PROJECTS
  const ourProjectsFiltered =
    activeOurProjectsFilter === 'ongoing'
      ? ongoingProjects
      : activeOurProjectsFilter === 'completed'
      ? completedProjects
      : activeOurProjectsFilter === 'upcoming'
      ? upcomingProjects
      : properties;

  const renderPropertyCard = (property: Property, showStatusSubBadge: boolean = false) => (
    <div
      key={property.id}
      className="bg-neutral-900/60 border border-neutral-800 rounded-sm overflow-hidden hover:border-amber-400/50 transition-all duration-300 flex flex-col justify-between group"
    >
      {/* Card Media Header */}
      <div>
        <div className="relative cursor-pointer" onClick={() => onOpenGallery(property)}>
          <ArchitecturalImage
            id={property.id}
            imageSrc={property.image}
            category={property.gallery[0]?.category || 'Exterior'}
            title={property.title}
            subtitle={property.subtitle}
            aspectRatio="16:9"
          />
          {/* Status Kicker Badge */}
          {property.statusKicker && (
            <div className="absolute top-4 left-4 bg-amber-400 text-neutral-950 px-2.5 py-0.5 rounded text-[11px] font-semibold uppercase tracking-wider shadow-md pointer-events-none">
              {property.statusKicker}
            </div>
          )}

          {/* Gallery Badge */}
          <div className="absolute top-4 right-4 bg-neutral-950/80 border border-neutral-700/80 px-2.5 py-1 rounded text-[11px] text-white flex items-center gap-1.5 backdrop-blur-sm pointer-events-none">
            <Maximize2 className="w-3 h-3 text-amber-400" />
            <span>{property.gallery.length} High-Res Views</span>
          </div>
        </div>

        {/* Card Content Body */}
        <div className="p-6">
          {/* Unboxed metadata */}
          <div className="flex flex-wrap items-center gap-2 text-xs text-neutral-400 mb-2">
            <span className="flex items-center gap-1 text-amber-300 font-medium">
              <MapPin className="w-3.5 h-3.5 text-amber-400" />
              {property.location}
            </span>
            <span aria-hidden="true">·</span>
            <span>{property.carpetAreaRange}</span>
            <span aria-hidden="true">·</span>
            <span className="text-neutral-300 font-medium">{property.status}</span>
          </div>

          {/* Status Sub Badge for OUR PROJECTS tab */}
          {showStatusSubBadge && (
            <div className="mb-3">
              {property.status === 'Under Construction' && (
                <span className="inline-flex items-center gap-1.5 px-2.5 py-1 text-[11px] font-semibold uppercase tracking-wider bg-amber-400/10 text-amber-300 border border-amber-400/30 rounded-xs">
                  <Clock className="w-3 h-3 text-amber-400" />
                  <span>ONGOING · Poss. {property.completionDate}</span>
                </span>
              )}
              {property.status === 'Ready to Move' && (
                <span className="inline-flex items-center gap-1.5 px-2.5 py-1 text-[11px] font-semibold uppercase tracking-wider bg-emerald-400/10 text-emerald-300 border border-emerald-400/30 rounded-xs">
                  <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                  <span>COMPLETED · Ready for Possession</span>
                </span>
              )}
              {property.status === 'New Launch' && (
                <span className="inline-flex items-center gap-1.5 px-2.5 py-1 text-[11px] font-semibold uppercase tracking-wider bg-sky-400/10 text-sky-300 border border-sky-400/30 rounded-xs">
                  <Sparkles className="w-3 h-3 text-sky-400" />
                  <span>UPCOMING · Pre-Launch Booking Open</span>
                </span>
              )}
            </div>
          )}

          <div className="flex items-baseline justify-between gap-4 mb-3">
            <h3 className="text-2xl font-serif font-medium text-white group-hover:text-amber-300 transition-colors">
              {property.title}
            </h3>
            <div className="text-right shrink-0">
              <span className="text-lg font-serif font-semibold text-amber-400 tabular-nums">
                {property.priceDisplay}
              </span>
            </div>
          </div>

          <p className="text-neutral-400 text-xs sm:text-sm font-light leading-relaxed mb-6 line-clamp-3">
            {property.description}
          </p>

          {/* Highlights Grid */}
          <div className="border-t border-b border-neutral-800/80 py-4 mb-6 grid grid-cols-2 gap-y-2.5 gap-x-4 text-xs text-neutral-300">
            {property.highlightSpecs.slice(0, 4).map((spec, i) => (
              <div key={i} className="flex items-center gap-2">
                <Sparkles className="w-3 h-3 text-amber-400 shrink-0" />
                <span className="truncate">{spec}</span>
              </div>
            ))}
          </div>

          {/* Ecological & Security Indicators */}
          <div className="flex flex-wrap items-center gap-4 text-xs text-neutral-400">
            {property.features.biometricSecurity && (
              <div className="flex items-center gap-1 text-neutral-300">
                <Key className="w-3.5 h-3.5 text-amber-400" />
                <span>Biometric Lock</span>
              </div>
            )}
            {property.features.solarGrid && (
              <div className="flex items-center gap-1 text-neutral-300">
                <Sun className="w-3.5 h-3.5 text-amber-400" />
                <span>5kW Solar</span>
              </div>
            )}
            {property.features.evCharging && (
              <div className="flex items-center gap-1 text-neutral-300">
                <Zap className="w-3.5 h-3.5 text-amber-400" />
                <span>EV Ready</span>
              </div>
            )}
            {property.features.vastuCompliant && (
              <div className="flex items-center gap-1 text-neutral-300">
                <span className="text-amber-400 font-serif">ॐ</span>
                <span>100% Vastu</span>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Card Footer Actions */}
      <div className="p-6 pt-0 flex flex-wrap items-center gap-3">
        <button
          onClick={() => onSelectPropertyForFloorPlan(property.id)}
          className="flex-1 min-w-[140px] py-2.5 bg-neutral-800 hover:bg-neutral-700 text-white text-xs font-medium tracking-wide uppercase rounded-sm transition-colors flex items-center justify-center gap-2 border border-neutral-700 cursor-pointer"
        >
          <Layers className="w-3.5 h-3.5 text-amber-400" />
          <span>Floor Plan Map</span>
        </button>
        <button
          onClick={() => onOpenBooking(property.title)}
          className="flex-1 min-w-[140px] py-2.5 bg-amber-400 hover:bg-amber-300 text-neutral-950 text-xs font-semibold tracking-wide uppercase rounded-sm transition-colors flex items-center justify-center gap-2 shadow-sm cursor-pointer"
        >
          <Calendar className="w-3.5 h-3.5" />
          <span>Book Visit</span>
        </button>
      </div>
    </div>
  );

  return (
    <div className="bg-[#080C14] text-neutral-100">
      {/* =========================================================================
          TAB: ALL PROJECTS (Complete Nagpur Developments Catalog)
          ========================================================================= */}
      <section id="all-projects" className="py-24 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 scroll-mt-20">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-8 pb-6 border-b border-neutral-800">
          <div>
            <div className="flex items-center gap-2 text-xs uppercase tracking-[0.25em] text-amber-400 font-medium mb-3">
              <span>ALL PROJECTS · COMPLETE NAGPUR PORTFOLIO</span>
            </div>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-serif font-normal tracking-tight text-white">
              All VEDMAY Developments
            </h2>
          </div>
          <p className="text-neutral-400 text-xs sm:text-sm font-light max-w-md mt-4 md:mt-0">
            Browse through our full spectrum of boutique ultra-luxury flats, landmark high-rise sky
            mansions, master-planned townships, and prime commercial hubs in Nagpur.
          </p>
        </div>

        {/* Category Filter Navigation Bar in Official Website Palette */}
        <div className="flex flex-wrap items-center gap-2 mb-10 p-3 bg-[#E8E6E1] border border-[#D4D1C8] rounded-sm text-[#14171F]">
          <span className="text-xs font-semibold text-[#14171F] uppercase tracking-wider mr-2 flex items-center gap-1.5">
            <Filter className="w-3.5 h-3.5 text-[#8D7039]" />
            <span>Category:</span>
          </span>
          <button
            onClick={() => setActiveCategory('all')}
            className={`px-4 py-2 text-xs font-semibold uppercase tracking-wider rounded-xs transition-all cursor-pointer ${
              activeCategory === 'all'
                ? 'bg-[#14171F] text-[#FAF9F6] border border-[#14171F] shadow-sm'
                : 'bg-[#FAF9F6] text-[#2D313A] hover:text-[#14171F] hover:bg-[#DDD8CF] border border-[#D4D1C8]'
            }`}
          >
            All Projects ({properties.length})
          </button>
          <button
            onClick={() => setActiveCategory('new-launches')}
            className={`px-4 py-2 text-xs font-semibold uppercase tracking-wider rounded-xs transition-all cursor-pointer ${
              activeCategory === 'new-launches'
                ? 'bg-[#14171F] text-[#FAF9F6] border border-[#14171F] shadow-sm'
                : 'bg-[#FAF9F6] text-[#2D313A] hover:text-[#14171F] hover:bg-[#DDD8CF] border border-[#D4D1C8]'
            }`}
          >
            New Launches ({newLaunches.length})
          </button>
          <button
            onClick={() => setActiveCategory('communities')}
            className={`px-4 py-2 text-xs font-semibold uppercase tracking-wider rounded-xs transition-all cursor-pointer ${
              activeCategory === 'communities'
                ? 'bg-[#14171F] text-[#FAF9F6] border border-[#14171F] shadow-sm'
                : 'bg-[#FAF9F6] text-[#2D313A] hover:text-[#14171F] hover:bg-[#DDD8CF] border border-[#D4D1C8]'
            }`}
          >
            Master Townships ({communities.length})
          </button>
          <button
            onClick={() => setActiveCategory('ready-to-move')}
            className={`px-4 py-2 text-xs font-semibold uppercase tracking-wider rounded-xs transition-all cursor-pointer ${
              activeCategory === 'ready-to-move'
                ? 'bg-[#14171F] text-[#FAF9F6] border border-[#14171F] shadow-sm'
                : 'bg-[#FAF9F6] text-[#2D313A] hover:text-[#14171F] hover:bg-[#DDD8CF] border border-[#D4D1C8]'
            }`}
          >
            Ready to Move ({delivered.length})
          </button>
          <button
            onClick={() => setActiveCategory('commercial')}
            className={`px-4 py-2 text-xs font-semibold uppercase tracking-wider rounded-xs transition-all cursor-pointer ${
              activeCategory === 'commercial'
                ? 'bg-[#14171F] text-[#FAF9F6] border border-[#14171F] shadow-sm'
                : 'bg-[#FAF9F6] text-[#2D313A] hover:text-[#14171F] hover:bg-[#DDD8CF] border border-[#D4D1C8]'
            }`}
          >
            Commercial ({commercial.length})
          </button>
        </div>

        {/* Display Filtered Cards */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
          {allFilteredProperties.map((property) => renderPropertyCard(property, false))}
        </div>
      </section>

      {/* =========================================================================
          TAB: OUR PROJECTS (WITH SUB TABS: ONGOING, COMPLETED, UPCOMING)
          ========================================================================= */}
      <section id="our-projects" className="py-24 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 border-t border-neutral-800/80 scroll-mt-20">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-8 pb-6 border-b border-neutral-800">
          <div>
            <div className="flex items-center gap-2 text-xs uppercase tracking-[0.25em] text-amber-400 font-medium mb-3">
              <span>OUR PROJECTS · SIGNATURE ARCHITECTURAL COLLECTION</span>
            </div>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-serif font-normal tracking-tight text-white">
              Signature Developments
            </h2>
          </div>
          <p className="text-neutral-400 text-xs sm:text-sm font-light max-w-md mt-4 md:mt-0">
            Engineered exclusively by VEDMAY with cutting-edge cantilevered terraces, Botticino marble,
            100% Vastu alignment, and rooftop lifestyle decks in Nagpur’s premier postcodes.
          </p>
        </div>

        {/* SUB TABS: ONGOING, COMPLETED, UPCOMING in Official Website Palette */}
        <div className="flex flex-wrap items-center justify-between gap-4 mb-10 p-3 bg-[#E8E6E1] border border-[#D4D1C8] rounded-sm text-[#14171F]">
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-xs font-semibold text-[#14171F] uppercase tracking-wider mr-2 flex items-center gap-1.5">
              <Building className="w-3.5 h-3.5 text-[#8D7039]" />
              <span>Project Sub Tab:</span>
            </span>
            <button
              onClick={() => handleOurProjectsFilterChange('all')}
              className={`px-4 py-2 text-xs font-semibold uppercase tracking-wider rounded-xs transition-all cursor-pointer ${
                activeOurProjectsFilter === 'all'
                  ? 'bg-[#14171F] text-[#FAF9F6] border border-[#14171F] shadow-sm'
                  : 'bg-[#FAF9F6] text-[#2D313A] hover:text-[#14171F] hover:bg-[#DDD8CF] border border-[#D4D1C8]'
              }`}
            >
              All ({properties.length})
            </button>
            <button
              onClick={() => handleOurProjectsFilterChange('ongoing')}
              className={`px-4 py-2 text-xs font-semibold uppercase tracking-wider rounded-xs transition-all cursor-pointer flex items-center gap-1.5 ${
                activeOurProjectsFilter === 'ongoing'
                  ? 'bg-[#14171F] text-[#FAF9F6] border border-[#14171F] shadow-sm'
                  : 'bg-[#FAF9F6] text-[#2D313A] hover:text-[#14171F] hover:bg-[#DDD8CF] border border-[#D4D1C8]'
              }`}
            >
              <Clock className="w-3 h-3 text-[#C5A869]" />
              <span>ONGOING ({ongoingProjects.length})</span>
            </button>
            <button
              onClick={() => handleOurProjectsFilterChange('completed')}
              className={`px-4 py-2 text-xs font-semibold uppercase tracking-wider rounded-xs transition-all cursor-pointer flex items-center gap-1.5 ${
                activeOurProjectsFilter === 'completed'
                  ? 'bg-[#14171F] text-[#FAF9F6] border border-[#14171F] shadow-sm'
                  : 'bg-[#FAF9F6] text-[#2D313A] hover:text-[#14171F] hover:bg-[#DDD8CF] border border-[#D4D1C8]'
              }`}
            >
              <CheckCircle2 className="w-3 h-3 text-emerald-600" />
              <span>COMPLETED ({completedProjects.length})</span>
            </button>
            <button
              onClick={() => handleOurProjectsFilterChange('upcoming')}
              className={`px-4 py-2 text-xs font-semibold uppercase tracking-wider rounded-xs transition-all cursor-pointer flex items-center gap-1.5 ${
                activeOurProjectsFilter === 'upcoming'
                  ? 'bg-[#14171F] text-[#FAF9F6] border border-[#14171F] shadow-sm'
                  : 'bg-[#FAF9F6] text-[#2D313A] hover:text-[#14171F] hover:bg-[#DDD8CF] border border-[#D4D1C8]'
              }`}
            >
              <Sparkles className="w-3 h-3 text-[#8D7039]" />
              <span>UPCOMING ({upcomingProjects.length})</span>
            </button>
          </div>

          <div className="text-xs text-neutral-400 font-mono">
            Showing <span className="text-amber-400 font-semibold">{ourProjectsFiltered.length}</span>{' '}
            {activeOurProjectsFilter === 'all'
              ? 'Signature Developments'
              : `${activeOurProjectsFilter.toUpperCase()} Projects`}
          </div>
        </div>

        {/* Render Filtered Cards for OUR PROJECTS */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
          {ourProjectsFiltered.map((property) => renderPropertyCard(property, true))}
        </div>
      </section>

      {/* Compatibility Anchors for deep links */}
      <div id="new-launches" className="sr-only" aria-hidden="true" />
      <div id="communities" className="sr-only" aria-hidden="true" />
      <div id="delivered" className="sr-only" aria-hidden="true" />
    </div>
  );
};
